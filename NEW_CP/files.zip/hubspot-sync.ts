import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const HUBSPOT_BASE = "https://api.hubapi.com";
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
// Stage ID -> pipeline name (core pipelines only; others = "Other")
const STAGE_PIPELINE_MAP = {
  "90210906":"EAP Private Sector","90210907":"EAP Private Sector","90210908":"EAP Private Sector",
  "90210909":"EAP Private Sector","90210911":"EAP Private Sector","90210912":"EAP Private Sector",
  "117061418":"EAP Private Sector","144190622":"EAP Private Sector",
  "144106655":"EAP (ROW)","90762297":"EAP (ROW)","85819792":"EAP (ROW)",
  "1095412884":"EAP (ROW)","85819796":"EAP (ROW)","85819797":"EAP (ROW)",
  "85819798":"EAP (ROW)","123108764":"EAP (ROW)","143535516":"EAP (ROW)",
  "1006298375":"Bespoke Analytics (EMEA & APAC)","1337894584":"Bespoke Analytics (EMEA & APAC)",
  "1224878717":"Bespoke Analytics (EMEA & APAC)","1062953595":"Bespoke Analytics (EMEA & APAC)",
  "1095399680":"Bespoke Analytics (EMEA & APAC)","230351409":"Bespoke Analytics (EMEA & APAC)",
  "230351410":"Bespoke Analytics (EMEA & APAC)","235225632":"Bespoke Analytics (EMEA & APAC)",
  "1006259853":"Bespoke Analytics (EMEA & APAC)",
  "48395866":"Public Sector (USA)","48395867":"Public Sector (USA)","48395868":"Public Sector (USA)",
  "48395869":"Public Sector (USA)","60815255":"Public Sector (USA)","60815256":"Public Sector (USA)",
  "60815257":"Public Sector (USA)","48395871":"Public Sector (USA)","48395870":"Public Sector (USA)",
  "127023991":"Public Sector (USA)","127023992":"Public Sector (USA)",
  "117886624":"Public Sector (India)","117886625":"Public Sector (India)","117886626":"Public Sector (India)",
  "117886627":"Public Sector (India)","117886628":"Public Sector (India)",
  "117886629":"Public Sector (India)","117886630":"Public Sector (India)",
  "1151307103":"Global Commercial Pipeline","1151307104":"Global Commercial Pipeline",
  "1151307106":"Global Commercial Pipeline","1151307108":"Global Commercial Pipeline",
  "1151307109":"Global Commercial Pipeline",
};
// 0=Discovery, 1=Technical Validation, 2=Quote/Solution, 3=Proposal,
// 4=Contracting & Negotiation, 5=Closed Won, 6=Closed Lost/Disqualified
const STAGE_ID_MAP = {
  "48395866":0,"48395867":0,"48395868":1,"48395869":3,"48395870":5,"48395871":6,
  "60198235":0,"60198236":1,"60198237":5,"60198238":5,"60198239":5,"60198241":6,
  "60815255":3,"60815256":4,"60815257":5,"60924027":0,"60924028":0,"60924029":0,
  "60924030":1,"60924031":1,"60924032":5,"60924033":6,"60924034":4,"60924035":4,
  "69169409":1,"85819792":1,"85819796":4,"85819797":5,"85819798":6,
  "90210906":0,"90210907":0,"90210908":1,"90210909":4,"90210911":5,"90210912":6,
  "90762297":0,"117061418":0,"117886624":3,"117886625":1,"117886626":2,
  "117886627":5,"117886628":5,"117886629":5,"117886630":6,
  "123108764":0,"127023991":6,"127023992":6,"143535516":6,"144106655":0,"144190622":6,
  "154652982":0,"154652983":0,"154652984":4,"154652985":5,"154652986":6,"154652987":5,
  "163102801":0,"230351409":4,"230351410":5,"235225632":0,
  "239358549":0,"239358550":0,"239358551":4,"239358554":5,"239358555":6,
  "1000629414":0,"1000629415":2,"1000629416":4,"1000629417":5,"1000629418":6,
  "1006259853":6,"1006298375":0,"1015522972":0,"1015522973":0,"1015522974":1,
  "1015522975":3,"1015522976":4,"1015522977":5,"1015522978":6,
  "1041603111":0,"1041603112":1,"1041603113":1,"1041603114":3,"1041603115":3,
  "1041603116":4,"1041603117":5,"1041645841":6,"1041645842":6,
  "1062953595":1,"1095399680":2,"1095412884":2,
  "1105135999":0,"1105136000":0,"1105136001":1,"1105136002":4,"1105136004":5,"1105136005":6,
  "1142695256":0,"1151307103":0,"1151307104":1,"1151307106":2,"1151307108":5,"1151307109":6,
  "1224878717":0,"1337894584":0,
};
const STAGE_LABELS = [
  "Discovery",                    // 0
  "Technical Validation",         // 1
  "Quote / Solution Scoping",     // 2
  "Proposal",                     // 3
  "Contracting & Negotiation",    // 4
  "Closed Won",                   // 5
  "Closed Lost",                  // 6
];
const STAGE_HS_IDS = ["appointmentscheduled","qualifiedtobuy","presentationscheduled","decisionmakerboughtin","contractsent","closedwon"];

async function hsGet(path, token) {
  const r = await fetch(HUBSPOT_BASE + path, {
    headers: { Authorization: "Bearer " + token },
  });
  if (!r.ok) throw new Error("HS " + r.status + ": " + await r.text());
  return r.json();
}

async function hsPatch(path, body, token) {
  const r = await fetch(HUBSPOT_BASE + path, {
    method: "PATCH",
    headers: { Authorization: "Bearer " + token, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error("HS PATCH " + r.status + ": " + await r.text());
  return r.json();
}

function stageIdx(s) { return STAGE_ID_MAP[s] !== undefined ? STAGE_ID_MAP[s] : 0; }
function stageLabel(i) { return STAGE_LABELS[i] || STAGE_LABELS[0]; }
function lastActivityLabel(iso) {
  if (!iso) return "Unknown";
  const h = Math.floor((Date.now() - new Date(iso).getTime()) / 3600000);
  if (h < 2) return "Just now";
  if (h < 24) return h + " hours ago";
  const d = Math.floor(h / 24);
  return d + (d !== 1 ? " days ago" : " day ago");
}

serve(async function(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  const token = Deno.env.get("HUBSPOT_TOKEN");
  if (!token) {
    return new Response(JSON.stringify({ ok: false, error: "HUBSPOT_TOKEN not set" }), {
      status: 500, headers: Object.assign({}, CORS, { "Content-Type": "application/json" }),
    });
  }

  const sb = createClient(
    Deno.env.get("SUPABASE_URL"),
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")
  );

  const body = req.method === "POST" ? await req.json().catch(function() { return {}; }) : {};

  // GET STAGES
  if (body.action === "get_stages") {
    const pipelines = await hsGet("/crm/v3/pipelines/deals", token);
    return new Response(JSON.stringify({ ok: true, pipelines: pipelines.results }), {
      headers: Object.assign({}, CORS, { "Content-Type": "application/json" }),
    });
  }

  // WRITE-BACK
  if (body.action === "update_deal") {
    const updates = {};
    if (body.stage_idx !== undefined) {
      updates.dealstage = STAGE_HS_IDS[body.stage_idx] || STAGE_HS_IDS[0];
    }
    if (Object.keys(updates).length) {
      await hsPatch("/crm/v3/objects/deals/" + body.hubspot_deal_id, { properties: updates }, token);
    }
    return new Response(JSON.stringify({ ok: true }), {
      headers: Object.assign({}, CORS, { "Content-Type": "application/json" }),
    });
  }

  // FULL SYNC
  // Roster: email -> clean display name (matches the app's TEAM_MEMBERS).
  // HubSpot owner names can be full legal names; we normalise by email.
  const ROSTER_NAME_BY_EMAIL = {
    "alex@pixxel.space":"Alex Koh Hock Poh","allyson@pixxel.space":"Allyson Jenkins",
    "anjul@pixxel.co.in":"Anjul Garg","ashay@pixxel.co.in":"Ashay Deo",
    "awais@pixxel.co.in":"Awais Ahmed","caio@pixxel.space":"Caio Miranda",
    "debashish@pixxel.co.in":"Gp Capt Debashish Sengupta (Retd)","jimmy@pixxel.space":"Jimmy Greco",
    "karan@pixxel.co.in":"Karan Mali","markus@pixxel.space":"Markus Heynen",
    "mauricio@pixxel.space":"Mauricio Meira","ryan.mckinney@pixxel.space":"Ryan McKinney",
    "shantanu@pixxel.co.in":"Shantanu Thada",
    "shridutta.banerjee@pixxel.co.in":"Shridutta Banerjee","shridutta@pixxel.co.in":"Shridutta Banerjee",
    "usha@pixxel.co.in":"Usha Simhadri","usha@pixxel.space":"Usha Simhadri",
    "amy@pixxel.space":"Amy Zammit","megan@pixxel.space":"Megan Gallagher",
    "rhodri@pixxel.space":"Rhodri Phillips","ryan@pixxel.space":"Ryan Hammock",
    "spencer@pixxel.space":"Spencer Wahrman","terence@pixxel.space":"Terence Yuchen Xie",
    "aditya@pixxel.co.in":"Aditya Chintalapati","ananya.banerjee@pixxel.co.in":"Ananya Banerjee",
    "jaya.bandi@pixxel.co.in":"Bandi Jay","megha@pixxel.co.in":"Megha Devaraju",
    "meghana.shetty@pixxel.co.in":"Meghana Shetty","shubhavi@pixxel.co.in":"Shubhavi P",
    "jeremy@pixxel.space":"Jeremy Kravitz","subash@pixxel.co.in":"Subash Yeggina",
  };

  const ownersRes = await hsGet("/crm/v3/owners?limit=100", token);
  const ownerMap = {};       // id -> clean display name
  const ownerEmailMap = {};  // id -> email
  for (const o of (ownersRes.results || [])) {
    const email = (o.email || "").toLowerCase();
    const rawName = ((o.firstName || "") + " " + (o.lastName || "")).trim();
    ownerMap[o.id] = ROSTER_NAME_BY_EMAIL[email] || rawName;
    ownerEmailMap[o.id] = email;
  }

  const props = "dealname,dealstage,amount,closedate,hubspot_owner_id,notes_last_contacted,hs_lastmodifieddate";
  let deals = [];
  let after = undefined;
  do {
    const url = "/crm/v3/objects/deals?limit=100&properties=" + props + (after ? "&after=" + after : "");
    const data = await hsGet(url, token);
    deals = deals.concat(data.results || []);
    after = data.paging && data.paging.next ? data.paging.next.after : undefined;
  } while (after);

  console.log("Fetched " + deals.length + " deals");

  const rows = deals.map(function(d) {
    const p = d.properties;
    const idx = stageIdx(p.dealstage);
    return {
      hubspot_deal_id: d.id,
      hubspot_deal_name: p.dealname,
      hubspot_stage: stageLabel(idx),
      hubspot_stage_idx: idx,
      hubspot_stage_id: p.dealstage || null,
      pipeline: STAGE_PIPELINE_MAP[p.dealstage] || "Other",
      hubspot_amount: p.amount ? parseFloat(p.amount) : null,
      hubspot_close_date: p.closedate || null,
      hubspot_last_contacted: p.notes_last_contacted || null,
      hubspot_last_contact_owner: ownerMap[p.hubspot_owner_id] || null,
      hubspot_synced_at: new Date().toISOString(),
      company: p.dealname || ("Deal " + d.id),
      // HubSpot deal owner = Sales Owner. Name is normalised to the roster
      // clean name via email. SE / CS / Analytics are assigned manually and
      // must never be overwritten by sync (we omit those columns here).
      owner_director: ownerMap[p.hubspot_owner_id] || null,
      owner_director_email: ownerEmailMap[p.hubspot_owner_id] || null,
      last_activity_label: lastActivityLabel(p.hs_lastmodifieddate),
      deal_id_display: "PX-" + d.id.slice(-4),
    };
  });

  let synced = 0;
  let errors = 0;
  const CHUNK = 50;
  for (let i = 0; i < rows.length; i += CHUNK) {
    const chunk = rows.slice(i, i + CHUNK);
    const result = await sb.from("handover_passports").upsert(chunk, { onConflict: "hubspot_deal_id" });
    if (result.error) { console.error("Chunk error:", result.error); errors += chunk.length; }
    else synced += chunk.length;
  }

  return new Response(JSON.stringify({ ok: true, synced: synced, errors: errors, total: deals.length, synced_at: new Date().toISOString() }), {
    headers: Object.assign({}, CORS, { "Content-Type": "application/json" }),
  });
});

import React, { useState, useMemo, useEffect } from "react";
import {
  Search, ChevronLeft, Download, Bell, FileText, MapPin, Users, Target,
  AlertTriangle, CheckCircle2, Circle, Clock, Paperclip, Send, BarChart3,
  LayoutGrid, Eye, Pencil, ExternalLink, Building2, Mail, Satellite, Layers,
  Activity, TrendingUp, X, Lock, Gauge, AtSign, Plus, Radar, ChevronDown,
  MessageSquare, Hash, Zap, RefreshCw, CheckCheck, Camera, ListChecks, CalendarClock
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Design system (spectral / Earth-observation theme)                */
/* ------------------------------------------------------------------ */
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@400;450;500;600&family=IBM+Plex+Mono:wght@400;500;600&display=swap');

.cp-root{
  --ink:#0B1220; --ink2:#1B2433; --muted:#5A6577; --muted2:#929BAB;
  --line:#E4E8EF; --line-soft:#EEF1F6; --surface:#F5F7FB; --card:#FFFFFF;
  --accent:#0EA5B7; --accent-deep:#0B7E8C; --accent-soft:#E3F6F8;
  --se:#2D7FF9; --se-soft:#E7F0FE; --cs:#E07A2B; --cs-soft:#FBEEDF;
  --an:#7A5AF5; --an-soft:#EDE8FE;
  --ok:#2FB67A; --warn:#E0B02B; --bad:#E5564B;
  --font-display:'Space Grotesk',ui-sans-serif,system-ui,sans-serif;
  --font-body:'Inter',ui-sans-serif,system-ui,sans-serif;
  --font-mono:'IBM Plex Mono',ui-monospace,monospace;
  font-family:var(--font-body); color:var(--ink); background:var(--surface);
  min-height:100vh; -webkit-font-smoothing:antialiased;
}
.cp-root *{box-sizing:border-box;}
.cp-root button{font-family:inherit; cursor:pointer; border:none; background:none;}
.mono{font-family:var(--font-mono);}
.disp{font-family:var(--font-display);}

/* top bar */
.cp-top{position:sticky;top:0;z-index:30;display:flex;align-items:center;gap:18px;
  padding:12px 24px;background:rgba(255,255,255,.82);backdrop-filter:blur(10px);
  border-bottom:1px solid var(--line);}
.cp-brand{display:flex;align-items:center;gap:10px;font-family:var(--font-display);
  font-weight:600;font-size:15px;letter-spacing:-.01em;}
.cp-brand .mark{width:30px;height:30px;border-radius:8px;display:grid;place-items:center;
  background:linear-gradient(135deg,#0B1220,#13314a);color:#fff;}
.cp-brand small{display:block;font-family:var(--font-mono);font-weight:500;font-size:9.5px;
  letter-spacing:.14em;color:var(--muted2);text-transform:uppercase;margin-top:1px;}
.cp-nav{display:flex;gap:4px;margin-left:6px;}
.cp-nav button{display:flex;align-items:center;gap:7px;padding:7px 13px;border-radius:8px;
  font-size:13px;font-weight:500;color:var(--muted);}
.cp-nav button.on{background:var(--ink);color:#fff;}
.cp-nav button:not(.on):hover{background:var(--line-soft);color:var(--ink);}
.cp-spacer{flex:1;}
.cp-viewtoggle{display:flex;align-items:center;background:var(--line-soft);border-radius:9px;
  padding:3px;gap:2px;}
.cp-viewtoggle button{display:flex;align-items:center;gap:6px;padding:6px 11px;border-radius:7px;
  font-size:12px;font-weight:500;color:var(--muted);}
.cp-viewtoggle button.on{background:#fff;color:var(--ink);box-shadow:0 1px 2px rgba(11,18,32,.08);}

.cp-page{max-width:1180px;margin:0 auto;padding:26px 24px 80px;}

/* readonly banner */
.cp-banner{display:flex;align-items:center;gap:10px;background:var(--cs-soft);
  border:1px solid #F0D9BE;color:#8a571f;border-radius:11px;padding:10px 14px;
  font-size:13px;margin-bottom:18px;}

/* filters */
.cp-filters{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:20px;}
.cp-search{flex:1;min-width:240px;display:flex;align-items:center;gap:9px;background:#fff;
  border:1px solid var(--line);border-radius:11px;padding:10px 14px;}
.cp-search input{border:none;outline:none;font-size:14px;flex:1;background:none;color:var(--ink);}
.cp-search input::placeholder{color:var(--muted2);}
.cp-select{position:relative;}
.cp-select select{appearance:none;background:#fff;border:1px solid var(--line);border-radius:11px;
  padding:10px 32px 10px 13px;font-size:13px;color:var(--ink);font-family:inherit;cursor:pointer;}
.cp-select .chev{position:absolute;right:11px;top:50%;transform:translateY(-50%);
  pointer-events:none;color:var(--muted2);}

/* deal grid */
.cp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:16px;}
.cp-card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:18px;
  cursor:pointer;transition:transform .12s ease,box-shadow .12s ease,border-color .12s ease;}
.cp-card:hover{transform:translateY(-2px);box-shadow:0 10px 28px -14px rgba(11,18,32,.28);
  border-color:#D4DAE4;}
.cp-card .row{display:flex;justify-content:space-between;gap:12px;}
.cp-card h3{font-family:var(--font-display);font-size:16.5px;font-weight:600;margin:0;
  letter-spacing:-.01em;line-height:1.2;}
.cp-sector{display:inline-flex;align-items:center;gap:6px;font-size:11.5px;color:var(--muted);
  margin-top:5px;}
.cp-amount{font-family:var(--font-mono);font-size:13px;font-weight:500;color:var(--ink2);}
.cp-card .owners{display:flex;gap:6px;margin-top:16px;}
.cp-card .meta{display:flex;align-items:center;gap:6px;font-size:11.5px;color:var(--muted2);
  margin-top:14px;}

/* avatar / owner chip */
.av{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:10px;
  font-weight:600;font-family:var(--font-mono);color:#fff;flex:none;}
.av.empty{background:#fff;border:1.5px dashed var(--line);color:var(--muted2);}
.av.se{background:var(--se);} .av.cs{background:var(--cs);} .av.an{background:var(--an);}
.role-tag{font-size:9px;font-family:var(--font-mono);letter-spacing:.1em;text-transform:uppercase;
  font-weight:600;}

/* stage chip */
.chip{display:inline-flex;align-items:center;gap:6px;padding:4px 9px;border-radius:7px;
  font-size:11px;font-weight:600;letter-spacing:.01em;}
.chip.live{background:var(--accent-soft);color:var(--accent-deep);}
.chip.won{background:#E3F7EC;color:#1f8a57;}
.chip.early{background:var(--line-soft);color:var(--muted);}

/* mini ring */
.ring-wrap{display:grid;place-items:center;position:relative;}
.ring-val{position:absolute;font-family:var(--font-mono);font-weight:600;}

/* ---- passport detail ---- */
.cp-back{display:inline-flex;align-items:center;gap:6px;font-size:13px;color:var(--muted);
  font-weight:500;margin-bottom:16px;}
.cp-back:hover{color:var(--ink);}

.cp-head{position:relative;overflow:hidden;background:linear-gradient(180deg,#0B1220,#10243a);
  border-radius:20px;padding:24px 26px;color:#fff;margin-bottom:18px;}
.cp-head .grat{position:absolute;inset:0;opacity:.5;pointer-events:none;
  background-image:linear-gradient(rgba(255,255,255,.05) 1px,transparent 1px),
    linear-gradient(90deg,rgba(255,255,255,.05) 1px,transparent 1px);
  background-size:34px 34px;
  mask-image:radial-gradient(120% 120% at 80% -10%,#000,transparent 70%);}
.cp-head .spectral{position:absolute;top:0;left:0;right:0;height:3px;
  background:linear-gradient(90deg,#6D5DF6,#2D7FF9,#0EA5B7,#2FB67A,#E0B02B,#E5564B);}
.cp-head .htop{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;
  position:relative;}
.cp-head h1{font-family:var(--font-display);font-size:24px;font-weight:600;margin:0;
  letter-spacing:-.015em;}
.cp-head .hsub{display:flex;align-items:center;gap:14px;margin-top:7px;font-size:12.5px;
  color:#9fb3c9;}
.cp-head .hsub .dot{width:3px;height:3px;border-radius:50%;background:#54708c;}
.h-actions{display:flex;gap:8px;flex-wrap:wrap;}
.btn{display:inline-flex;align-items:center;gap:7px;padding:8px 13px;border-radius:9px;
  font-size:12.5px;font-weight:500;transition:.12s;}
.btn.ghost{background:rgba(255,255,255,.08);color:#dbe6f2;border:1px solid rgba(255,255,255,.12);}
.btn.ghost:hover{background:rgba(255,255,255,.15);}
.btn.solid{background:var(--accent);color:#06262b;font-weight:600;}
.btn.solid:hover{background:#15b9cc;}
.btn:disabled{opacity:.45;cursor:not-allowed;}

/* stage progress */
.stage-bar{display:flex;gap:5px;margin-top:20px;position:relative;}
.stage-seg{flex:1;}
.stage-seg .bar{height:5px;border-radius:3px;background:rgba(255,255,255,.13);}
.stage-seg.done .bar{background:var(--accent);}
.stage-seg.cur .bar{background:linear-gradient(90deg,var(--accent),#7fe3ee);}
.stage-seg .lbl{font-size:9.5px;margin-top:7px;color:#7e93aa;font-weight:500;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.stage-seg.done .lbl,.stage-seg.cur .lbl{color:#cfe0f0;}

/* ownership + readiness rail */
.cp-railrow{display:grid;grid-template-columns:1fr auto;gap:16px;margin-bottom:18px;
  align-items:stretch;}
@media(max-width:760px){.cp-railrow{grid-template-columns:1fr;}}
.owners-panel{background:#fff;border:1px solid var(--line);border-radius:16px;padding:16px 18px;
  display:flex;gap:26px;flex-wrap:wrap;align-items:center;}
.owner-slot{display:flex;align-items:center;gap:10px;position:relative;}
.owner-slot .meta .role-tag{color:var(--muted2);}
.owner-slot .meta .nm{font-size:13px;font-weight:500;margin-top:2px;}
.owner-slot .assign{font-size:12px;color:var(--accent-deep);font-weight:500;}
.assign-menu{position:absolute;top:42px;left:0;z-index:20;background:#fff;border:1px solid var(--line);
  border-radius:11px;box-shadow:0 14px 40px -16px rgba(11,18,32,.35);padding:6px;min-width:170px;}
.assign-menu button{display:block;width:100%;text-align:left;padding:8px 10px;border-radius:8px;
  font-size:13px;color:var(--ink);}
.assign-menu button:hover{background:var(--line-soft);}

.readiness-panel{background:#fff;border:1px solid var(--line);border-radius:16px;padding:14px 20px;
  display:flex;align-items:center;gap:16px;cursor:pointer;min-width:230px;}
.readiness-panel:hover{border-color:#D4DAE4;}
.readiness-panel .txt .k{font-family:var(--font-mono);font-size:9.5px;letter-spacing:.12em;
  text-transform:uppercase;color:var(--muted2);}
.readiness-panel .txt .v{font-family:var(--font-display);font-size:15px;font-weight:600;margin-top:2px;}
.readiness-panel .txt small{font-size:11px;color:var(--muted);}

/* checklist popover */
.checklist{background:#fff;border:1px solid var(--line);border-radius:16px;padding:16px 18px;
  margin-bottom:18px;}
.checklist h4{font-family:var(--font-display);font-size:13px;font-weight:600;margin:0 0 12px;}
.checklist .items{display:grid;grid-template-columns:1fr 1fr;gap:8px 22px;}
@media(max-width:620px){.checklist .items{grid-template-columns:1fr;}}
.cl-item{display:flex;align-items:center;gap:9px;font-size:13px;color:var(--ink2);}
.cl-item.miss{color:var(--muted2);}

/* tabs */
.cp-tabs{display:flex;gap:2px;border-bottom:1px solid var(--line);margin-bottom:22px;}
.cp-tabs button{display:flex;align-items:center;gap:7px;padding:11px 16px;font-size:13.5px;
  font-weight:500;color:var(--muted);position:relative;}
.cp-tabs button.on{color:var(--ink);font-weight:600;}
.cp-tabs button.on::after{content:"";position:absolute;left:12px;right:12px;bottom:-1px;height:2px;
  background:var(--accent);border-radius:2px;}

/* content blocks */
.cols{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
@media(max-width:760px){.cols{grid-template-columns:1fr;}}
.block{background:#fff;border:1px solid var(--line);border-radius:16px;padding:18px 20px;
  margin-bottom:16px;}
.block .bhead{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;}
.block .bhead .lhs{display:flex;align-items:center;gap:9px;}
.block h3{font-family:var(--font-display);font-size:13.5px;font-weight:600;margin:0;
  letter-spacing:.005em;}
.block .ic{width:28px;height:28px;border-radius:8px;display:grid;place-items:center;
  background:var(--accent-soft);color:var(--accent-deep);}
.kv{display:flex;flex-direction:column;gap:11px;}
.kv .k{font-family:var(--font-mono);font-size:9.5px;letter-spacing:.1em;text-transform:uppercase;
  color:var(--muted2);margin-bottom:3px;}
.kv .v{font-size:13.5px;line-height:1.55;color:var(--ink2);}
.tags{display:flex;flex-wrap:wrap;gap:6px;}
.tag{font-size:11.5px;font-weight:500;padding:4px 9px;border-radius:7px;background:var(--line-soft);
  color:var(--ink2);}
.tag.spec{background:var(--accent-soft);color:var(--accent-deep);font-family:var(--font-mono);}
.li{display:flex;gap:10px;font-size:13.5px;line-height:1.5;color:var(--ink2);margin-bottom:9px;}
.li .b{color:var(--accent);flex:none;margin-top:5px;width:5px;height:5px;border-radius:50%;
  background:var(--accent);}
.link{display:inline-flex;align-items:center;gap:6px;font-size:13px;color:var(--accent-deep);
  font-weight:500;}
.empty{display:flex;align-items:center;gap:10px;font-size:13px;color:var(--muted2);
  border:1px dashed var(--line);border-radius:11px;padding:13px 14px;}
.empty button{margin-left:auto;font-size:12px;color:var(--accent-deep);font-weight:500;
  display:inline-flex;align-items:center;gap:5px;}

/* AOI map */
.aoi{border-radius:14px;overflow:hidden;border:1px solid var(--line);position:relative;
  background:#0c1a26;}
.aoi .cap{position:absolute;left:12px;bottom:12px;background:rgba(8,18,28,.72);
  backdrop-filter:blur(4px);border:1px solid rgba(255,255,255,.12);border-radius:9px;
  padding:8px 11px;color:#dfeaf3;font-family:var(--font-mono);font-size:10.5px;line-height:1.6;}
.aoi .badge{position:absolute;right:12px;top:12px;background:rgba(8,18,28,.72);
  border:1px solid rgba(255,255,255,.12);border-radius:8px;padding:5px 9px;color:#9fe7ef;
  font-family:var(--font-mono);font-size:10px;display:flex;align-items:center;gap:6px;}

/* risk rows */
.risk{display:flex;gap:11px;align-items:flex-start;padding:11px 0;border-top:1px solid var(--line-soft);}
.risk:first-child{border-top:none;}
.risk .sev{font-size:9.5px;font-family:var(--font-mono);font-weight:600;letter-spacing:.08em;
  padding:3px 7px;border-radius:6px;flex:none;text-transform:uppercase;}
.sev.high{background:#FCE6E4;color:#b13b32;} .sev.med{background:#FBF1D8;color:#9a7415;}
.sev.low{background:#E7F1FE;color:#2c66c4;}

/* notes / activity */
.composer{background:#fff;border:1px solid var(--line);border-radius:16px;padding:14px 16px;
  margin-bottom:16px;}
.composer textarea{width:100%;border:none;outline:none;resize:none;font-family:inherit;
  font-size:13.5px;color:var(--ink);min-height:54px;background:none;}
.composer textarea::placeholder{color:var(--muted2);}
.composer .crow{display:flex;align-items:center;justify-content:space-between;margin-top:8px;
  padding-top:10px;border-top:1px solid var(--line-soft);}
.composer .hint{font-size:11.5px;color:var(--muted2);display:flex;align-items:center;gap:6px;}
.feed-item{display:flex;gap:12px;padding:13px 0;border-top:1px solid var(--line-soft);}
.feed-item:first-child{border-top:none;}
.feed-item .ft{font-size:13.5px;line-height:1.55;color:var(--ink2);}
.feed-item .fm{font-size:11px;color:var(--muted2);margin-top:4px;font-family:var(--font-mono);}
.feed-item .mention{color:var(--se);font-weight:500;}
.attach{display:flex;align-items:center;gap:11px;padding:11px 12px;border:1px solid var(--line);
  border-radius:11px;margin-bottom:8px;}
.attach .ai{width:34px;height:34px;border-radius:8px;background:var(--line-soft);display:grid;
  place-items:center;color:var(--muted);flex:none;}
.attach .an2{font-size:13px;font-weight:500;} .attach .as{font-size:11px;color:var(--muted2);}

/* dashboard */
.dash-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:18px;}
@media(max-width:820px){.dash-grid{grid-template-columns:repeat(2,1fr);}}
.stat{background:#fff;border:1px solid var(--line);border-radius:16px;padding:16px 18px;}
.stat .k{font-family:var(--font-mono);font-size:9.5px;letter-spacing:.12em;text-transform:uppercase;
  color:var(--muted2);}
.stat .v{font-family:var(--font-display);font-size:27px;font-weight:600;margin-top:6px;
  letter-spacing:-.02em;}
.stat .d{font-size:11.5px;color:var(--muted);margin-top:4px;display:flex;align-items:center;gap:5px;}
.barlist{display:flex;flex-direction:column;gap:13px;}
.barlist .br{display:grid;grid-template-columns:150px 1fr 38px;align-items:center;gap:12px;
  font-size:12.5px;}
.barlist .track{height:8px;background:var(--line-soft);border-radius:5px;overflow:hidden;}
.barlist .fill{height:100%;border-radius:5px;background:linear-gradient(90deg,var(--accent),#6fd9e6);}
.alert-row{display:flex;align-items:center;gap:12px;padding:11px 0;border-top:1px solid var(--line-soft);
  cursor:pointer;}
.alert-row:first-child{border-top:none;}
.alert-row:hover .anm{color:var(--accent-deep);}
.alert-row .anm{font-size:13.5px;font-weight:500;}
.alert-row .as2{font-size:11.5px;color:var(--muted);}

/* toast */
.toast{position:fixed;bottom:22px;left:50%;transform:translateX(-50%);z-index:60;
  background:var(--ink);color:#fff;padding:12px 18px;border-radius:12px;font-size:13px;
  display:flex;align-items:center;gap:10px;box-shadow:0 16px 40px -12px rgba(11,18,32,.5);}
.toast .spectral-dot{width:7px;height:7px;border-radius:50%;
  background:linear-gradient(90deg,#0EA5B7,#2FB67A);}

.section-title{font-family:var(--font-display);font-size:18px;font-weight:600;margin:0 0 4px;
  letter-spacing:-.01em;}
.section-sub{font-size:13px;color:var(--muted);margin:0 0 22px;}

/* logo / wordmark */
.cp-root{--dir:#0B6E7A;}
.av.dir{background:var(--dir);}
.cp-logo-img{height:22px;width:auto;display:block;}
.cp-wordmark{font-family:var(--font-display);font-weight:700;font-size:21px;letter-spacing:-.045em;
  color:var(--ink);line-height:1;}
.cp-wordmark .x{color:var(--accent);}
.cp-brand-div{width:1px;height:22px;background:var(--line);margin:0 2px;}

/* HubSpot sync pill */
.hs-pill{display:flex;align-items:center;gap:8px;background:#fff;border:1px solid var(--line);
  border-radius:9px;padding:6px 8px 6px 11px;font-size:11.5px;color:var(--muted);}
.hs-dot{width:7px;height:7px;border-radius:50%;background:var(--ok);
  box-shadow:0 0 0 3px rgba(47,182,122,.15);}
.hs-pill b{color:var(--ink);font-weight:600;}
.hs-pill .syncnow{display:inline-flex;align-items:center;gap:5px;color:var(--accent-deep);
  font-weight:500;font-size:11.5px;padding:4px 8px;border-radius:7px;}
.hs-pill .syncnow:hover{background:var(--accent-soft);}
.hs-writeback{display:inline-flex;align-items:center;gap:7px;margin-top:14px;position:relative;
  font-size:11px;color:#9fb3c9;font-family:var(--font-mono);}

/* notification bell + panel */
.bell{position:relative;}
.bell .btn-bell{width:38px;height:38px;border-radius:10px;display:grid;place-items:center;
  color:var(--muted);border:1px solid var(--line);background:#fff;}
.bell .btn-bell:hover{color:var(--ink);border-color:#D4DAE4;}
.bell .badge{position:absolute;top:-5px;right:-5px;min-width:17px;height:17px;padding:0 4px;
  border-radius:9px;background:var(--bad);color:#fff;font-size:10px;font-weight:700;
  display:grid;place-items:center;font-family:var(--font-mono);border:2px solid #fff;}
.notif-panel{position:absolute;top:46px;right:0;z-index:40;width:340px;background:#fff;
  border:1px solid var(--line);border-radius:14px;box-shadow:0 22px 60px -22px rgba(11,18,32,.4);
  overflow:hidden;}
.notif-head{display:flex;align-items:center;justify-content:space-between;padding:13px 15px;
  border-bottom:1px solid var(--line-soft);}
.notif-head h4{font-family:var(--font-display);font-size:13.5px;font-weight:600;margin:0;}
.notif-head button{font-size:11.5px;color:var(--accent-deep);font-weight:500;}
.notif-list{max-height:340px;overflow-y:auto;}
.notif-item{display:flex;gap:11px;padding:12px 15px;border-bottom:1px solid var(--line-soft);
  position:relative;}
.notif-item:last-child{border-bottom:none;}
.notif-item.unread{background:#F3FBFC;}
.notif-item .nt{font-size:12.5px;line-height:1.5;color:var(--ink2);}
.notif-item .nt b{font-weight:600;}
.notif-item .nch{display:flex;align-items:center;gap:6px;margin-top:5px;font-size:10.5px;
  color:var(--muted2);font-family:var(--font-mono);}
.notif-empty{padding:26px 15px;text-align:center;font-size:12.5px;color:var(--muted2);}

/* Slack integration */
.slack-pill{display:flex;align-items:center;gap:7px;background:#fff;border:1px solid var(--line);
  border-radius:9px;padding:6px 10px;font-size:11.5px;color:var(--muted);}
.slack-dot{width:7px;height:7px;border-radius:50%;background:#4A154B;}
.slack-pill b{color:var(--ink);font-weight:600;}
.slack-btn{display:inline-flex;align-items:center;gap:5px;color:#4A154B;font-weight:600;
  font-size:11.5px;padding:4px 8px;border-radius:7px;background:rgba(74,21,75,.06);}
.slack-btn:hover{background:rgba(74,21,75,.12);}
.slack-btn.sending{opacity:.55;pointer-events:none;}
.btn.slack{background:#4A154B;color:#fff;font-weight:600;}
.btn.slack:hover{background:#3d1040;}
.btn.slack.sending{opacity:.55;pointer-events:none;}
.slack-status{display:flex;align-items:center;gap:8px;padding:10px 14px;background:#F9F5FA;
  border:1px solid #e5d5e6;border-radius:11px;font-size:12.5px;color:#4A154B;margin-top:10px;}
.slack-status.err{background:#FEF2F2;border-color:#fcc;color:#b91c1c;}
.channel-select{display:flex;align-items:center;gap:8px;background:var(--line-soft);
  border-radius:9px;padding:7px 12px;margin-top:12px;}
.channel-select label{font-size:11.5px;color:var(--muted);font-weight:500;white-space:nowrap;}
.channel-select select{background:transparent;border:none;outline:none;font-size:12.5px;
  color:var(--ink);font-family:inherit;cursor:pointer;flex:1;}

/* ---- Customer Feedback tab ---- */
.fb-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;flex-wrap:wrap;gap:12px;}
.fb-sat-bar{display:flex;gap:8px;flex-wrap:wrap;}
.sat-chip{display:inline-flex;align-items:center;gap:6px;padding:5px 11px;border-radius:20px;
  font-size:11.5px;font-weight:600;cursor:pointer;border:1.5px solid transparent;}
.sat-chip.all{background:var(--line-soft);color:var(--muted);border-color:var(--line);}
.sat-chip.all.on{background:var(--ink);color:#fff;border-color:var(--ink);}
.sat-chip.vs{background:#FCE6E4;color:#b13b32;} .sat-chip.vs.on{border-color:#b13b32;}
.sat-chip.s{background:#FBF1D8;color:#9a7415;} .sat-chip.s.on{border-color:#9a7415;}
.sat-chip.sat{background:#E3F7EC;color:#1f8a57;} .sat-chip.sat.on{border-color:#1f8a57;}
.sat-chip.vsat{background:var(--accent-soft);color:var(--accent-deep);} .sat-chip.vsat.on{border-color:var(--accent-deep);}
.sat-chip.neu{background:var(--line-soft);color:var(--muted);} .sat-chip.neu.on{border-color:var(--muted);}
.fb-notion-btn{display:inline-flex;align-items:center;gap:7px;font-size:12px;font-weight:500;
  color:var(--muted);border:1px solid var(--line);border-radius:9px;padding:7px 13px;background:#fff;}
.fb-notion-btn:hover{color:var(--ink);border-color:#D4DAE4;}
.fb-card{background:#fff;border:1px solid var(--line);border-radius:16px;margin-bottom:14px;overflow:hidden;}
.fb-card-head{display:flex;align-items:center;gap:14px;padding:16px 20px;cursor:pointer;}
.fb-card-head:hover{background:var(--line-soft);}
.fb-card-head .sat-badge{flex:none;}
.fb-card-head .co{flex:1;}
.fb-card-head .co .title{font-size:14px;font-weight:600;font-family:var(--font-display);}
.fb-card-head .co .meta{font-size:11.5px;color:var(--muted2);margin-top:3px;display:flex;
  align-items:center;gap:8px;font-family:var(--font-mono);}
.fb-card-body{padding:0 20px 18px;border-top:1px solid var(--line-soft);}
.fb-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px 24px;margin-top:16px;}
@media(max-width:640px){.fb-grid{grid-template-columns:1fr;}}
.fb-grid .k{font-family:var(--font-mono);font-size:9.5px;letter-spacing:.1em;
  text-transform:uppercase;color:var(--muted2);margin-bottom:4px;}
.fb-grid .v{font-size:13px;color:var(--ink2);line-height:1.5;}
.fb-insights{margin-top:14px;padding:14px;background:var(--surface);border-radius:10px;
  border-left:3px solid var(--accent);font-size:13.5px;line-height:1.6;color:var(--ink2);}
.fb-ids{display:flex;flex-wrap:wrap;gap:6px;margin-top:4px;}
.fb-id{font-family:var(--font-mono);font-size:11px;padding:3px 7px;background:var(--line-soft);
  border-radius:6px;color:var(--ink2);}
.fb-add{display:flex;align-items:center;gap:9px;padding:14px 18px;border:1.5px dashed var(--line);
  border-radius:14px;font-size:13px;color:var(--muted);cursor:pointer;margin-top:4px;}
.fb-add:hover{border-color:var(--accent);color:var(--accent-deep);background:var(--accent-soft);}
.sat-dot{width:9px;height:9px;border-radius:50%;flex:none;}
.fb-empty{text-align:center;padding:40px 20px;color:var(--muted2);}
.fb-empty h4{font-family:var(--font-display);font-size:16px;font-weight:600;color:var(--muted);margin:12px 0 6px;}
.fb-notion-banner{display:flex;align-items:center;gap:12px;background:#FAFAFA;border:1px solid var(--line);
  border-radius:12px;padding:13px 16px;margin-bottom:18px;font-size:12.5px;color:var(--muted);}
.fb-notion-banner .nb-title{font-weight:600;color:var(--ink);font-size:13px;}
.fb-notion-banner .nb-status{display:flex;align-items:center;gap:6px;margin-top:3px;}
.notion-dot{width:7px;height:7px;border-radius:50%;background:#888;}
.notion-dot.linked{background:var(--ok);}
.fb-notion-banner .connect-btn{margin-left:auto;display:inline-flex;align-items:center;gap:6px;
  background:var(--ink);color:#fff;border-radius:8px;padding:7px 12px;font-size:12px;font-weight:500;white-space:nowrap;}
.fb-notion-banner .connect-btn:hover{background:#1B2433;}

/* ── Feature: per-section last-updated stamp ── */
.sec-stamp{display:inline-flex;align-items:center;gap:5px;font-size:10.5px;font-family:var(--font-mono);
  color:var(--muted2);padding:3px 7px;background:var(--line-soft);border-radius:6px;}

/* ── Feature: last contact (HubSpot) in deal header ── */
.last-contact{display:flex;align-items:center;gap:7px;background:rgba(255,255,255,.08);
  border:1px solid rgba(255,255,255,.13);border-radius:9px;padding:7px 12px;font-size:12px;
  color:#cfe0f0;margin-top:14px;flex-wrap:wrap;gap:14px;}
.last-contact .lc-item{display:flex;align-items:center;gap:6px;}
.last-contact .lc-dot{width:7px;height:7px;border-radius:50%;}
.lc-dot.warm{background:#2FB67A;} .lc-dot.cool{background:#E0B02B;} .lc-dot.cold{background:#E5564B;}
.last-contact .lc-label{font-family:var(--font-mono);font-size:9.5px;letter-spacing:.1em;
  text-transform:uppercase;color:#7e93aa;margin-right:2px;}

/* ── Feature: capture / image progress log ── */
.clog-wrap{display:flex;flex-direction:column;gap:0;}
.clog-entry{display:flex;gap:14px;align-items:flex-start;padding:11px 0;
  border-bottom:1px solid var(--line-soft);}
.clog-entry:last-child{border-bottom:none;}
.clog-timeline{display:flex;flex-direction:column;align-items:center;gap:0;flex:none;padding-top:3px;}
.clog-dot{width:10px;height:10px;border-radius:50%;flex:none;}
.clog-line{width:2px;flex:1;background:var(--line);min-height:16px;margin-top:3px;}
.clog-status{font-size:10.5px;font-weight:700;font-family:var(--font-mono);padding:3px 8px;
  border-radius:6px;flex:none;text-transform:uppercase;letter-spacing:.06em;}
.cs-tasked{background:#E7F0FE;color:var(--se);}
.cs-captured{background:var(--accent-soft);color:var(--accent-deep);}
.cs-qcprog{background:#FBF1D8;color:#9a7415;}
.cs-qcpass{background:#E3F7EC;color:#1f8a57;}
.cs-qcfail{background:#FCE6E4;color:#b13b32;}
.cs-shared{background:#EDE8FE;color:var(--an);}
.clog-meta{font-size:11px;font-family:var(--font-mono);color:var(--muted2);margin-top:3px;}
.clog-note{font-size:13px;color:var(--ink2);line-height:1.5;margin-top:4px;}
.clog-reason{display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:600;
  color:#b13b32;background:#FCE6E4;border-radius:6px;padding:2px 7px;margin-top:5px;}
.clog-add{display:flex;align-items:center;gap:8px;padding:10px 14px;border:1.5px dashed var(--line);
  border-radius:11px;font-size:13px;color:var(--muted);cursor:pointer;margin-top:10px;}
.clog-add:hover{border-color:var(--accent);color:var(--accent-deep);background:var(--accent-soft);}
.clog-form{background:var(--surface);border-radius:12px;padding:16px;margin-top:10px;
  border:1px solid var(--line);}
.clog-form-row{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;}
@media(max-width:600px){.clog-form-row{grid-template-columns:1fr;}}

/* ── Feature: structured action plan ── */
.ap-tabs{display:flex;gap:4px;margin-bottom:16px;}
.ap-tab{padding:6px 14px;border-radius:8px;font-size:12.5px;font-weight:500;color:var(--muted);
  border:1px solid transparent;}
.ap-tab.on{background:#fff;border-color:var(--line);color:var(--ink);
  box-shadow:0 1px 3px rgba(11,18,32,.07);}
.ap-item{display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border-radius:12px;
  margin-bottom:8px;border:1px solid var(--line);background:#fff;transition:.12s;}
.ap-item:hover{border-color:#D4DAE4;}
.ap-item.done-item{opacity:.55;}
.ap-check{width:20px;height:20px;border-radius:6px;border:2px solid var(--line);
  display:grid;place-items:center;cursor:pointer;flex:none;margin-top:1px;}
.ap-check.checked{background:var(--ok);border-color:var(--ok);}
.ap-item .ap-task{font-size:13.5px;flex:1;line-height:1.45;}
.ap-item .ap-task.done-text{text-decoration:line-through;color:var(--muted2);}
.ap-item .ap-meta{font-size:11px;font-family:var(--font-mono);color:var(--muted2);margin-top:4px;
  display:flex;gap:10px;flex-wrap:wrap;}
.ap-due.overdue{color:var(--bad);font-weight:600;}
.ap-due.thisweek{color:var(--warn);font-weight:600;}
.ap-add-row{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap;}
.ap-add-row input,.ap-add-row select{border:1px solid var(--line);border-radius:9px;
  padding:8px 12px;font-size:13px;font-family:inherit;outline:none;background:#fff;}
.ap-add-row input{flex:1;min-width:180px;}
.ap-add-row select{min-width:130px;}
.ap-add-row input[type=date]{min-width:140px;}
`;



/* ------------------------------------------------------------------ */
/*  Constants + mock data                                             */
/* ------------------------------------------------------------------ */
const STAGES = ["Discovery", "Technical Qualification", "Solution Validation", "Proposal", "Negotiation", "Closed Won"];
// ── Drop the official Pixxel logo here (host it in Supabase storage or import it
//    in Lovable, then paste the URL). Empty string falls back to the wordmark. ──
const PIXXEL_LOGO_URL = "";

// ── Real Pixxel roster, grouped by team ──────────────────────
// Source: HubSpot users export (active only). Each person has a clean
// display name, email (matches HubSpot + Gmail), and Slack ID where known.
// "owner" = Sales Owner (the HubSpot deal owner). SE / CS / Analytics
// are assigned manually and only members of that team are pickable.
const TEAM_MEMBERS = {
  owner: [
    { name: "Alex Koh Hock Poh", email: "alex@pixxel.space", slack: "U08Q0722W82" },
    { name: "Allyson Jenkins", email: "allyson@pixxel.space", slack: "U085JVDKCMR" },
    { name: "Anjul Garg", email: "anjul@pixxel.co.in", slack: "U03DEGHSEM6" },
    { name: "Ashay Deo", email: "ashay@pixxel.co.in", slack: "U078BTL1TJT" },
    { name: "Awais Ahmed", email: "awais@pixxel.co.in", slack: null },
    { name: "Caio Miranda", email: "caio@pixxel.space", slack: "U0983ARJA5U" },
    { name: "Gp Capt Debashish Sengupta (Retd)", email: "debashish@pixxel.co.in", slack: "U06UHEYB65U" },
    { name: "Jimmy Greco", email: "jimmy@pixxel.space", slack: "U057D8LTT6K" },
    { name: "Karan Mali", email: "karan@pixxel.co.in", slack: "U07FE2KPZBR" },
    { name: "Markus Heynen", email: "markus@pixxel.space", slack: "U03MLS656U9" },
    { name: "Mauricio Meira", email: "mauricio@pixxel.space", slack: "U08NXMHA1NJ" },
    { name: "Ryan McKinney", email: "ryan.mckinney@pixxel.space", slack: "U0ACVKZ837T" },
    { name: "Shantanu Thada", email: "shantanu@pixxel.co.in", slack: "U05T154T9L5" },
    { name: "Shridutta Banerjee", email: "shridutta.banerjee@pixxel.co.in", slack: "U027F7R2EQ3" },
    { name: "Usha Simhadri", email: "usha@pixxel.co.in", slack: "U03EAV4FZSB" },
  ],
  se: [
    { name: "Amy Zammit", email: "amy@pixxel.space", slack: "U050FJYSEUU" },
    { name: "Megan Gallagher", email: "megan@pixxel.space", slack: "U056T9UE23V" },
    { name: "Rhodri Phillips", email: "rhodri@pixxel.space", slack: "U092KJ4AKPC" },
    { name: "Ryan Hammock", email: "ryan@pixxel.space", slack: "U057QQ2BA8J" },
    { name: "Spencer Wahrman", email: "spencer@pixxel.space", slack: "U07RWUTR22X" },
    { name: "Terence Yuchen Xie", email: "terence@pixxel.space", slack: "U0B8T6ZSL7N" },
  ],
  cs: [
    { name: "Aditya Chintalapati", email: "aditya@pixxel.co.in", slack: "U03MA603292" },
    { name: "Ananya Banerjee", email: "ananya.banerjee@pixxel.co.in", slack: "U0A3M8TLWVD" },
    { name: "Bandi Jay", email: "jaya.bandi@pixxel.co.in", slack: "U09UQH43Z5E" },
    { name: "Megha Devaraju", email: "megha@pixxel.co.in", slack: "U07N71LAVU0" },
    { name: "Meghana Shetty", email: "meghana.shetty@pixxel.co.in", slack: "U0A10SR26JX" },
    { name: "Shubhavi P", email: "shubhavi@pixxel.co.in", slack: "U053Z522G20" },
  ],
  analytics: [
    { name: "Jeremy Kravitz", email: "jeremy@pixxel.space", slack: "U064U233N2V" },
    { name: "Subash Yeggina", email: "subash@pixxel.co.in", slack: "U01TK168BKR" },
  ],
};

// Name-only arrays for dropdowns (role-restricted)
const TEAM = {
  owner: TEAM_MEMBERS.owner.map(p => p.name),
  se: TEAM_MEMBERS.se.map(p => p.name),
  cs: TEAM_MEMBERS.cs.map(p => p.name),
  analytics: TEAM_MEMBERS.analytics.map(p => p.name),
};

// Flat lookup: name -> {email, slack}, and email -> name (for HubSpot matching)
const PERSON_BY_NAME = {};
const NAME_BY_EMAIL = {};
Object.values(TEAM_MEMBERS).flat().forEach(p => {
  PERSON_BY_NAME[p.name] = p;
  if (p.email) NAME_BY_EMAIL[p.email.toLowerCase()] = p.name;
});

const ROLE_LABEL = { owner: "Sales Owner", se: "Sales Engineering", cs: "Customer Success", analytics: "Analytics" };
const ROLE_SHORT = { owner: "dir", se: "se", cs: "cs", analytics: "an" };
const ORDER = ["owner", "se", "cs", "analytics"];
const emailFor = (n) => PERSON_BY_NAME[n] ? PERSON_BY_NAME[n].email : "";
const slackFor = (n) => PERSON_BY_NAME[n] ? PERSON_BY_NAME[n].slack : null;
// kept for existing references
const SES = TEAM.se, CSS_OWN = TEAM.cs, ANS = TEAM.analytics;

/* ------------------------------------------------------------------ */
/*  Slack integration helpers                                         */
/* ------------------------------------------------------------------ */
// Real channels discovered from your Pixxel workspace
// Create these in Slack — the IDs below are placeholders until they exist;
// once created, paste the real channel IDs from Slack's channel settings.
const SLACK_CHANNELS = [
  { id: "C0BB1DC6LNB", name: "#customer-passport", label: "#customer-passport" },
];
const DEFAULT_CHANNEL = SLACK_CHANNELS[0];

// Sends a Slack message via the Anthropic API with the Slack MCP server.
// Returns { ok, error? }
async function sendToSlack(channelId, message) {
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        system: "You are a Slack notification bot. When asked to send a Slack message, use the slack_send_message tool immediately with the channel_id and message provided. Do nothing else.",
        messages: [{
          role: "user",
          content: `Send this message to Slack channel_id="${channelId}":\n\n${message}`
        }],
        mcp_servers: [{ type: "url", url: "https://mcp.slack.com/mcp", name: "slack" }],
      }),
    });
    if (!res.ok) return { ok: false, error: `API error ${res.status}` };
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

function fmtSlackAssignment(person, roleLabel, deal, score) {
  return `:satellite: *Pixxel Customer Passport — New Assignment*\n\n` +
    `*${person}* has been assigned as *${roleLabel}* on *${deal.company}*.\n\n` +
    `> *Deal:* ${deal.company} (${deal.id})\n` +
    `> *Stage:* ${STAGES[deal.stage]}\n` +
    `> *ACV:* ${deal.amount ? "$" + (deal.amount / 1000).toFixed(0) + "k" : "TBD"}\n` +
    `> *Handover readiness:* ${score}%\n\n` +
    `_Log in to the Customer Passport to view the full briefing._`;
}

function fmtSlackDealSummary(deal, score) {
  const o = deal.owners;
  return `:earth_americas: *Deal Update — ${deal.company}* (${deal.id})\n\n` +
    `*Stage:* ${STAGES[deal.stage]}   *ACV:* ${deal.amount ? "$" + (deal.amount / 1000).toFixed(0) + "k" : "TBD"}   *Readiness:* ${score}%\n\n` +
    `*Owners:*\n` +
    (o.owner ? `• Sales Owner: ${o.owner}\n` : "") +
    (o.se ? `• Sales Engineering: ${o.se}\n` : "") +
    (o.cs ? `• Customer Success: ${o.cs}\n` : "") +
    (o.analytics ? `• Analytics: ${o.analytics}\n` : "") +
    `\n_Posted from the Pixxel Customer Passport_`;
}

const initials = (n) => n ? n.split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase() : "";

const DEALS = [
  {
    id: "PX-1042", company: "AgriSense Global", sector: "Precision Agriculture",
    stage: 2, amount: 480000, hubspotId: "HS-88412", lastActivity: "2 days ago",
    lastContact: { date: "14 Jun 2026", owner: "Ravi Menon", warmth: "warm", daysAgo: 4 },
    sectionStamps: {
      profile: { by: "Ravi Menon", at: "Jun 12 · 14:30" },
      context: { by: "Ravi Menon", at: "May 30 · 10:00" },
      execution: { by: "Priya Shah", at: "Jun 14 · 09:00" },
    },
    owners: { director: "Anita Desai", se: "Ravi Menon", cs: "Priya Shah", analytics: "Yuki Tanaka" },
    profile: {
      contacts: [
        { name: "Dr. Elena Voss", role: "VP Agronomy", email: "evoss@agrisense.io" },
        { name: "Caleb Ruiz", role: "Head of Data", email: "cruiz@agrisense.io" },
      ],
      team: "Mature data-science team (8 FTE), existing Sentinel-2 pipeline, Python/GEE proficient. Comfortable with reflectance products, new to hyperspectral indices.",
      useCase: "Field-level crop stress and nitrogen status mapping across managed farmland to drive variable-rate fertilizer prescriptions for enterprise growers.",
      painPoints: "Multispectral indices (NDVI) saturate at canopy closure and miss early nutrient stress. They need narrow-band sensitivity to catch problems 10–14 days earlier.",
      supportNeeds: "Spectral index cookbook, onboarding workshop for the data team, and API access for automated tasking.",
      tech: {
        dataSources: ["Hyperspectral (Firefly)", "Multispectral fusion"],
        bandset: "VNIR 400–1000nm, 5nm sampling (~120 bands)",
        cadence: "Weekly revisit, growing season (Apr–Sep)",
        aoiLink: true, feasibilityLink: true,
      },
    },
    context: {
      problem: "Existing NDVI-based prescriptions miss sub-clinical nitrogen and water stress until yield is already affected, costing an estimated 6–9% of potential output on high-value crops.",
      objectives: [
        "Detect nitrogen stress 10+ days before visible symptoms",
        "Deliver field-ready prescription maps within 48h of capture",
        "Validate against ground-truth tissue sampling on 12 pilot fields",
      ],
      aoi: { name: "Central Valley pilot block", center: "36.74°N, 119.77°W", area: "4,180 ha", poly: "18,72 30,40 52,30 74,44 80,68 60,82 34,86" },
    },
    execution: {
      successCriteria: [
        "≥ 0.8 correlation between spectral N-index and lab tissue analysis",
        "Stress detection lead time ≥ 10 days vs. NDVI baseline",
        "Data team can run the workflow unaided after onboarding",
      ],
      pocs: [
        { name: "Nitrogen index validation", status: "In progress", note: "3 of 12 fields captured" },
      ],
      sampleData: ["2 hyperspectral scenes delivered (Mar)", "Reflectance + N-index GeoTIFFs"],
      risks: [
        { sev: "med", text: "Cloud cover in target window may compress the weekly cadence." },
        { sev: "low", text: "Tissue-sampling schedule depends on grower availability." },
      ],
      nextSteps: "Complete remaining 9 field captures, run validation, then move to Proposal with a per-hectare subscription model and a 3-year framework.",
      commercial: "Annual subscription, per-hectare tiered. Est. ACV $480k expanding to $1.2M at full acreage.",
      captureLog: [
        { id:"cl1", date:"2026-05-30", status:"Tasked", failReason:"", note:"First capture window opened. Tasked over NV-3 block.", author:"Ravi Menon", ts:"May 30 · 09:10" },
        { id:"cl2", date:"2026-06-02", status:"QC Failed", failReason:"Cloud cover", note:"Scene unusable — >60% cloud cover over AOI. Re-task requested.", author:"Yuki Tanaka", ts:"Jun 02 · 11:45" },
        { id:"cl3", date:"2026-06-07", status:"Captured", failReason:"", note:"Clean scene acquired. Forwarded to QC pipeline.", author:"Yuki Tanaka", ts:"Jun 07 · 16:20" },
        { id:"cl4", date:"2026-06-09", status:"QC Passed", failReason:"", note:"LSF FWHM within spec. Geolocation shift <2px. Reflectance calibration validated.", author:"Yuki Tanaka", ts:"Jun 09 · 14:05" },
        { id:"cl5", date:"2026-06-10", status:"Shared", failReason:"", note:"N-index GeoTIFF delivered to AgriSense data team via secure link.", author:"Ravi Menon", ts:"Jun 10 · 10:30" },
        { id:"cl6", date:"2026-06-15", status:"QC Failed", failReason:"BBR", note:"Second scene failed BBR threshold on 3 bands. Escalated to imagery team.", author:"Yuki Tanaka", ts:"Jun 15 · 08:50" },
        { id:"cl7", date:"2026-06-17", status:"Captured", failReason:"", note:"Re-capture successful. In QC queue.", author:"Yuki Tanaka", ts:"Jun 17 · 17:00" },
      ],
      sampleAoi: { name: "Sample delivery area — field blocks A3–A7", center: "36.71°N, 119.74°W", area: "1,240 ha", poly: "22,44 38,32 58,38 62,56 46,68 28,62" },
      actionItems: [
        { id:"a1", task:"Send N-index derivation notebook to AgriSense data team", owner:"Ravi Menon", due:"2026-06-20", done:false },
        { id:"a2", task:"Schedule onboarding workshop — confirm date with Dr. Voss", owner:"Priya Shah", due:"2026-06-21", done:false },
        { id:"a3", task:"Chase AgriSense for ground-truth tissue samples from 3 pilot fields", owner:"Ravi Menon", due:"2026-06-25", done:false },
        { id:"a4", task:"Complete feasibility check for weekly revisit cadence Apr–Sep", owner:"Yuki Tanaka", due:"2026-06-18", done:true },
        { id:"a5", task:"Resolve BBR failure on Jun 15 scene — re-deliver by EOM", owner:"Yuki Tanaka", due:"2026-06-30", done:false },
      ],
    },
    notes: {
      meetings: [
        { date: "Jun 12", author: "Ravi Menon", text: "Workshop scoping call. Data team wants index recipes in a notebook, not a black box. Adjusting onboarding plan." },
        { date: "May 30", author: "Ravi Menon", text: "Technical validation kickoff. AOI confirmed, feasibility check passed for weekly revisit." },
      ],
      activity: [
        { date: "Jun 14 · 09:12", author: "Priya Shah", text: "Reviewed handover readiness — looks ready for CS shadowing once POC closes. @Ravi Menon can you add the onboarding deck?", mentions: ["Ravi Menon"] },
        { date: "Jun 12 · 16:40", author: "Ravi Menon", text: "Updated support needs after workshop call." },
        { date: "Jun 10 · 11:05", author: "Yuki Tanaka", text: "Assigned as Analytics owner." },
      ],
      attachments: [
        { name: "AgriSense_Feasibility_v2.pdf", type: "pdf", size: "1.4 MB" },
        { name: "N-index_validation_plan.xlsx", type: "sheet", size: "88 KB" },
      ],
    },
    feedback: [
      {
        id: "fb-1", date: "2026-06-05", type: "Client",
        satisfaction: "Satisfied",
        keyInsights: "Team impressed with VNIR index sensitivity vs. NDVI. Requested a worked notebook showing the N-index derivation so they can self-serve future analyses.",
        imageBandsets: ["VNIR 400–1000nm"],
        imageIds: ["FF03_20260605_00501045_00000812_L2A"],
        customerExpertise: "Expert",
        softwareUsed: "Python / GEE",
        followUpDate: "2026-06-19",
        followUpAssignedTo: "Priya Shah",
        supportingFiles: [],
        notionPageId: "",
      },
    ],
  },
  {
    id: "PX-1039", company: "Permian Methane Watch", sector: "Energy · Oil & Gas",
    stage: 1, amount: 720000, hubspotId: "HS-88207", lastActivity: "5 hours ago",
    lastContact: { date: "17 Jun 2026", owner: "Lena Hofer", warmth: "warm", daysAgo: 1 },
    sectionStamps: { profile: { by: "Lena Hofer", at: "Jun 16 · 15:00" }, context: { by: "Lena Hofer", at: "Jun 16 · 15:00" }, execution: { by: "Marcus Webb", at: "Jun 17 · 06:30" } },
    owners: { director: "Greg Powell", se: "Lena Hofer", cs: "Marcus Webb", analytics: null },
    profile: {
      contacts: [
        { name: "James Holloway", role: "Director, ESG & Emissions", email: "jholloway@permianmw.com" },
      ],
      team: "Small remote-sensing group (3 FTE) inside ESG function. Strong domain knowledge, limited hyperspectral experience.",
      useCase: "Detect, quantify and attribute methane plumes across upstream assets to meet OGMP 2.0 reporting and reduce fugitive emissions.",
      painPoints: "Current aerial surveys are infrequent and expensive; they miss intermittent leaks and can't cover the full asset footprint at the needed frequency.",
      supportNeeds: "Plume quantification methodology, regulatory-grade reporting outputs, alerting workflow.",
      tech: {
        dataSources: ["Hyperspectral (Firefly)", "SWIR methane bands"],
        bandset: "SWIR 2000–2400nm (CH4 absorption), targeted band subset",
        cadence: "Bi-weekly over priority assets",
        aoiLink: true, feasibilityLink: false,
      },
    },
    context: {
      problem: "Fugitive methane is both a climate liability and a regulatory exposure. Without frequent wide-area monitoring, leaks persist undetected between costly aerial campaigns.",
      objectives: [
        "Detect plumes down to a defined emission-rate threshold",
        "Provide source attribution to asset/equipment level",
        "Generate OGMP-aligned reporting outputs",
      ],
      aoi: { name: "Delaware Basin priority assets", center: "31.9°N, 103.5°W", area: "12,600 ha", poly: "14,30 46,18 82,26 86,58 64,80 28,74 10,52" },
    },
    execution: {
      successCriteria: [
        "Detection of controlled-release plumes in blind test",
        "False-positive rate within agreed tolerance",
      ],
      pocs: [
        { name: "Controlled-release blind test", status: "Scheduled", note: "Vendor comparison, Q3" },
      ],
      sampleData: ["1 SWIR demo scene (archive)"],
      risks: [
        { sev: "high", text: "Detection threshold vs. competitor airborne LIDAR is the key commercial battleground — must prove in blind test." },
        { sev: "med", text: "Feasibility check for SWIR cadence not yet linked." },
      ],
      nextSteps: "Link feasibility study, lock blind-test protocol with customer, and assign an Analytics owner before POC.",
      commercial: "",
      captureLog: [
        { id:"pcl1", date:"2026-06-10", status:"Tasked", failReason:"", note:"SWIR window opened over Delaware Basin priority assets.", author:"Lena Hofer", ts:"Jun 10 · 10:00" },
      ],
      sampleAoi: null,
      actionItems: [
        { id:"pa1", task:"Link feasibility study to passport", owner:"Lena Hofer", due:"2026-06-20", done:false },
        { id:"pa2", task:"Assign Analytics owner before POC scoping", owner:"Greg Powell", due:"2026-06-19", done:false },
      ],
    },
    notes: {
      meetings: [
        { date: "Jun 16", author: "Lena Hofer", text: "Customer wants a head-to-head blind test against their current airborne provider. High bar but winnable." },
      ],
      activity: [
        { date: "Jun 17 · 06:30", author: "Lena Hofer", text: "Flagged: still need an Analytics owner before the POC can be scoped." },
        { date: "Jun 16 · 15:20", author: "Marcus Webb", text: "Joined as CS owner — will sit in on blind-test planning." },
      ],
      attachments: [
        { name: "OGMP_reporting_requirements.pdf", type: "pdf", size: "640 KB" },
      ],
    },
    feedback: [],
  },
  {
    id: "PX-1051", company: "AquaClear Water District", sector: "Environmental · Water",
    stage: 5, amount: 310000, hubspotId: "HS-88599", lastActivity: "1 day ago",
    lastContact: { date: "16 Jun 2026", owner: "Dana Cole", warmth: "warm", daysAgo: 2 },
    sectionStamps: { profile: { by: "Tom Castellano", at: "Jun 09 · 17:00" }, context: { by: "Tom Castellano", at: "Jun 09 · 17:00" }, execution: { by: "Dana Cole", at: "Jun 16 · 10:00" } },
    owners: { director: "Anita Desai", se: "Tom Castellano", cs: "Dana Cole", analytics: "Sam Okoro" },
    profile: {
      contacts: [
        { name: "Maria Santos", role: "Water Quality Manager", email: "msantos@aquaclear.gov" },
        { name: "Derek Lin", role: "GIS Analyst", email: "dlin@aquaclear.gov" },
      ],
      team: "GIS team of 4, ArcGIS-based, no prior hyperspectral. Will need full onboarding and managed delivery.",
      useCase: "Monitor harmful algal blooms (HABs) and turbidity across reservoirs to protect drinking-water intake and trigger treatment responses early.",
      painPoints: "Manual water sampling is sparse and lagging; blooms are detected after they've already reached intake points.",
      supportNeeds: "Fully managed bloom-alert service, dashboard, integration with their incident workflow.",
      tech: {
        dataSources: ["Hyperspectral (Firefly)"],
        bandset: "VNIR with red-edge & phycocyanin bands (~620nm, 650nm)",
        cadence: "Twice weekly, year-round",
        aoiLink: true, feasibilityLink: true,
      },
    },
    context: {
      problem: "Algal blooms threaten drinking-water safety and are detected too late by manual sampling, forcing reactive and costly treatment.",
      objectives: [
        "Detect bloom onset across all 3 reservoirs",
        "Provide a turbidity & chlorophyll-a proxy product",
        "Deliver alerts into the district's incident system",
      ],
      aoi: { name: "Three-reservoir network", center: "44.05°N, 121.3°W", area: "2,240 ha", poly: "20,28 44,20 50,42 72,38 78,64 50,78 24,66 16,46" },
    },
    execution: {
      successCriteria: [
        "Bloom onset detected ≥ 5 days before manual sampling",
        "Alert delivered to incident system within 24h of capture",
        "GIS team adopts dashboard as primary monitoring tool",
      ],
      pocs: [
        { name: "Bloom detection pilot", status: "Complete", note: "Validated on 2024 bloom season archive" },
      ],
      sampleData: ["Full 2024 season reprocessed", "Chlorophyll-a proxy maps delivered"],
      risks: [
        { sev: "low", text: "Onboarding load on a small GIS team — phase the rollout." },
      ],
      nextSteps: "Contract signed. Begin CS-led onboarding, stand up the alert integration, and schedule the kickoff workshop.",
      commercial: "3-year managed-service agreement, $310k ACV. Renewal hinges on demonstrated alert reliability.",
      captureLog: [
        { id:"acl1", date:"2026-05-20", status:"Captured", failReason:"", note:"Full bloom-season archive reprocessed.", author:"Sam Okoro", ts:"May 20 · 14:00" },
        { id:"acl2", date:"2026-05-28", status:"QC Passed", failReason:"", note:"Chlorophyll-a proxy validated against manual samples.", author:"Sam Okoro", ts:"May 28 · 09:30" },
        { id:"acl3", date:"2026-06-02", status:"Shared", failReason:"", note:"Full 2024 season maps delivered to AquaClear GIS team.", author:"Dana Cole", ts:"Jun 02 · 11:00" },
      ],
      sampleAoi: { name: "Reservoir 2 sample delivery area", center: "44.02°N, 121.28°W", area: "680 ha", poly: "30,35 50,28 62,45 55,62 36,58" },
      actionItems: [
        { id:"aa1", task:"Stand up bloom-alert integration with district incident system", owner:"Sam Okoro", due:"2026-06-28", done:false },
        { id:"aa2", task:"Schedule kickoff onboarding workshop with GIS team", owner:"Dana Cole", due:"2026-06-22", done:false },
        { id:"aa3", task:"Chase AquaClear for incident system API credentials", owner:"Dana Cole", due:"2026-06-24", done:false },
      ],
    },
    notes: {
      meetings: [
        { date: "Jun 9", author: "Tom Castellano", text: "Closed won! Handover to Dana for onboarding. POC results were the deciding factor." },
      ],
      activity: [
        { date: "Jun 16 · 10:00", author: "Dana Cole", text: "Onboarding plan drafted. @Sam Okoro let's align on the alert-integration spec this week.", mentions: ["Sam Okoro"] },
        { date: "Jun 09 · 17:30", author: "Tom Castellano", text: "Moved deal to Closed Won. Handover initiated." },
      ],
      attachments: [
        { name: "AquaClear_POC_results.pdf", type: "pdf", size: "2.1 MB" },
        { name: "Onboarding_plan.docx", type: "doc", size: "120 KB" },
      ],
    },
    feedback: [
      {
        id: "fb-2", date: "2026-06-10", type: "Client",
        satisfaction: "Very Satisfied",
        keyInsights: "Bloom detection exceeded expectations — alert lead time was 7 days ahead of manual sampling. GIS team appreciated the ArcGIS-compatible outputs. Requested a higher revisit frequency during peak summer bloom season.",
        imageBandsets: ["VNIR red-edge", "Phycocyanin 620nm"],
        imageIds: ["FF01_20260608_00501045_00010124_L2A", "FF01_20260610_00501045_00010985_L2A"],
        customerExpertise: "Intermediate",
        softwareUsed: "ArcGIS Pro",
        followUpDate: "2026-06-24",
        followUpAssignedTo: "Dana Cole",
        supportingFiles: ["AquaClear_POC_results.pdf"],
        notionPageId: "",
      },
      {
        id: "fb-3", date: "2026-05-15", type: "Client",
        satisfaction: "Satisfied",
        keyInsights: "Mid-POC check-in. Data delivery workflow smooth. Some confusion around L2A vs. reflectance products — needs a short technical brief for the GIS team.",
        imageBandsets: ["VNIR 400–750nm"],
        imageIds: ["FF01_20260514_00501045_00009812_L2A"],
        customerExpertise: "Intermediate",
        softwareUsed: "ArcGIS Pro",
        followUpDate: "2026-05-22",
        followUpAssignedTo: "Tom Castellano",
        supportingFiles: [],
        notionPageId: "",
      },
    ],
  },
  {
    id: "PX-1047", company: "NorthVein Minerals", sector: "Mining · Exploration",
    stage: 3, amount: 560000, hubspotId: "HS-88471", lastActivity: "3 days ago",
    lastContact: { date: "11 Jun 2026", owner: "Ravi Menon", warmth: "cool", daysAgo: 7 },
    sectionStamps: { profile: { by: "Ravi Menon", at: "Jun 11 · 14:00" }, context: { by: "Ravi Menon", at: "Jun 11 · 14:00" }, execution: { by: "Elise Berg", at: "Jun 11 · 14:05" } },
    owners: { director: "Sofia Marchetti", se: "Ravi Menon", cs: null, analytics: "Elise Berg" },
    profile: {
      contacts: [
        { name: "Anja Kowalski", role: "Chief Geologist", email: "akowalski@northvein.com" },
      ],
      team: "Exploration geology team, strong on spectral mineralogy concepts, uses ENVI.",
      useCase: "Map alteration mineralogy over greenfield licence areas to prioritise drill targets and de-risk exploration spend.",
      painPoints: "Ground surveys are slow and expensive over remote terrain; they want to narrow drill targets before mobilising crews.",
      supportNeeds: "Mineral mapping deliverables, integration with their ENVI workflow.",
      tech: {
        dataSources: ["Hyperspectral (Firefly)", "SWIR mineralogy"],
        bandset: "VNIR–SWIR 400–2500nm, full spectrum",
        cadence: "One-time campaign + targeted re-fly",
        aoiLink: true, feasibilityLink: false,
      },
    },
    context: {
      problem: "",
      objectives: [
        "Produce alteration-mineral maps over 3 licence blocks",
        "Identify and rank candidate drill targets",
      ],
      aoi: { name: "Licence block NV-3", center: "23.4°S, 119.7°E", area: "8,900 ha", poly: "22,24 56,16 84,32 78,62 50,80 22,70 12,46" },
    },
    execution: {
      successCriteria: [],
      pocs: [],
      sampleData: ["1 archive SWIR scene shared"],
      risks: [
        { sev: "med", text: "No CS owner assigned yet; commercial pathway undefined." },
      ],
      nextSteps: "Build proposal once feasibility and success criteria are defined. Assign CS owner.",
      commercial: "",
      captureLog: [
        { id:"ncl1", date:"2026-06-11", status:"Tasked", failReason:"", note:"SWIR capture tasked over NV-3 licence block pending fresh scene approval.", author:"Elise Berg", ts:"Jun 11 · 14:30" },
      ],
      sampleAoi: null,
      actionItems: [
        { id:"na1", task:"Define success criteria with Anja Kowalski before next call", owner:"Ravi Menon", due:"2026-06-24", done:false },
        { id:"na2", task:"Assign CS owner to unblock commercial pathway", owner:"Sofia Marchetti", due:"2026-06-19", done:false },
      ],
    },
    notes: {
      meetings: [
        { date: "Jun 11", author: "Ravi Menon", text: "Promising fit — geology team already thinks in spectral terms. Need to firm up success criteria before proposal." },
      ],
      activity: [
        { date: "Jun 11 · 14:00", author: "Elise Berg", text: "Assigned as Analytics owner." },
      ],
      attachments: [],
    },
    feedback: [
      {
        id: "fb-4", date: "2026-06-11", type: "Client",
        satisfaction: "Neutral",
        keyInsights: "Geology team can see the spectral differentiation potential for clay mineralogy but want to see real SWIR data over their licence block before committing. Archive scene insufficient — needs a fresh capture over NV-3.",
        imageBandsets: ["SWIR 2000–2400nm"],
        imageIds: ["FF03_20260411_00501045_00008812_L2A (archive)"],
        customerExpertise: "Expert",
        softwareUsed: "ENVI Classic",
        followUpDate: "2026-06-25",
        followUpAssignedTo: "Ravi Menon",
        supportingFiles: [],
        notionPageId: "",
      },
    ],
  },
  {
    id: "PX-1044", company: "Sentinel Defense Solutions", sector: "Defense · Intelligence",
    stage: 4, amount: 1250000, hubspotId: "HS-88333", lastActivity: "6 days ago",
    lastContact: { date: "06 Jun 2026", owner: "Lena Hofer", warmth: "cool", daysAgo: 12 },
    sectionStamps: { profile: { by: "Lena Hofer", at: "Jun 06 · 12:00" }, context: { by: "Lena Hofer", at: "Jun 06 · 12:00" }, execution: { by: "Marcus Webb", at: "Jun 06 · 12:05" } },
    owners: { director: "Greg Powell", se: "Lena Hofer", cs: "Marcus Webb", analytics: "Yuki Tanaka" },
    profile: {
      contacts: [
        { name: "Col. (Ret.) David Pearce", role: "Program Lead", email: "dpearce@sentinel-ds.com" },
      ],
      team: "Cleared geospatial analysts. Detailed requirements, procurement-heavy process.",
      useCase: "Wide-area change detection and material identification for monitoring activity in areas of strategic interest.",
      painPoints: "",
      supportNeeds: "Secure delivery, tasking flexibility, change-detection products.",
      tech: {
        dataSources: ["Hyperspectral (Firefly)"],
        bandset: "Full VNIR–SWIR, change-detection product",
        cadence: "On-demand tasking, priority queue",
        aoiLink: false, feasibilityLink: true,
      },
    },
    context: {
      problem: "Persistent monitoring of strategic areas requires frequent, taskable wide-area coverage that current assets can't sustain affordably.",
      objectives: [],
      aoi: null,
    },
    execution: {
      successCriteria: [
        "Tasking turnaround within agreed SLA",
        "Change-detection accuracy meets program threshold",
      ],
      pocs: [
        { name: "Change-detection demo", status: "Complete", note: "Passed technical evaluation" },
      ],
      sampleData: ["Classified demo (details restricted)"],
      risks: [
        { sev: "high", text: "Long procurement cycle and security review may slip timeline by a quarter." },
        { sev: "med", text: "AOI not yet linked in passport (handling separately due to sensitivity)." },
      ],
      nextSteps: "In contract negotiation. Finalise SLA terms and security annex.",
      commercial: "Multi-year framework, $1.25M ACV. Negotiating tasking-volume tiers.",
      captureLog: [
        { id:"scl1", date:"2026-05-15", status:"Captured", failReason:"", note:"Demo scene acquired. Details restricted.", author:"Lena Hofer", ts:"May 15 · 09:00" },
        { id:"scl2", date:"2026-05-20", status:"QC Passed", failReason:"", note:"Internal QC passed. Demo delivered via secure channel.", author:"Yuki Tanaka", ts:"May 20 · 11:00" },
        { id:"scl3", date:"2026-05-22", status:"Shared", failReason:"", note:"Shared with program evaluation team.", author:"Lena Hofer", ts:"May 22 · 14:00" },
      ],
      sampleAoi: null,
      actionItems: [
        { id:"sa1", task:"Finalise SLA tasking-priority tiers with program lead", owner:"Lena Hofer", due:"2026-06-25", done:false },
        { id:"sa2", task:"Legal review of security annex", owner:"Marcus Webb", due:"2026-06-30", done:false },
      ],
    },
    notes: {
      meetings: [
        { date: "Jun 6", author: "Lena Hofer", text: "Negotiation focused on SLA and tasking priority. Technical eval already passed." },
      ],
      activity: [
        { date: "Jun 06 · 12:00", author: "Marcus Webb", text: "Reviewing security annex requirements for handover readiness." },
      ],
      attachments: [
        { name: "Change_detection_eval.pdf", type: "pdf", size: "3.0 MB" },
      ],
    },
    feedback: [
      {
        id: "fb-5", date: "2026-06-06", type: "Client",
        satisfaction: "Very Satisfied",
        keyInsights: "Technical evaluation passed. Change-detection product met all accuracy thresholds. Program lead specifically noted the tasking-responsiveness as a differentiator vs. current providers.",
        imageBandsets: ["Full VNIR–SWIR"],
        imageIds: ["RESTRICTED"],
        customerExpertise: "Expert",
        softwareUsed: "Classified",
        followUpDate: "2026-06-20",
        followUpAssignedTo: "Marcus Webb",
        supportingFiles: ["Change_detection_eval.pdf"],
        notionPageId: "",
      },
    ],
  },
  {
    id: "PX-1053", company: "Cerrado Forest Authority", sector: "Environmental · Forestry",
    stage: 0, amount: 0, hubspotId: "HS-88640", lastActivity: "4 days ago",
    lastContact: { date: "13 Jun 2026", owner: "Tom Castellano", warmth: "cold", daysAgo: 5 },
    sectionStamps: { profile: { by: "Tom Castellano", at: "Jun 13 · 09:00" }, context: {}, execution: {} },
    owners: { director: null, se: "Tom Castellano", cs: null, analytics: null },
    profile: {
      contacts: [
        { name: "Bruno Almeida", role: "Conservation Lead", email: "balmeida@cerrado.org.br" },
      ],
      team: "",
      useCase: "Monitor land-use change and degradation across protected savanna for enforcement and reporting.",
      painPoints: "",
      supportNeeds: "",
      tech: { dataSources: [], bandset: "", cadence: "", aoiLink: false, feasibilityLink: false },
    },
    context: {
      problem: "",
      objectives: [],
      aoi: null,
    },
    execution: { successCriteria: [], pocs: [], sampleData: [], risks: [], nextSteps: "", commercial: "", captureLog: [], sampleAoi: null, actionItems: [] },
    notes: {
      meetings: [
        { date: "Jun 13", author: "Tom Castellano", text: "Intro call. Early days — exploring whether hyperspectral adds value over their current optical monitoring." },
      ],
      activity: [
        { date: "Jun 13 · 09:00", author: "Tom Castellano", text: "Created passport after discovery call." },
      ],
      attachments: [],
    },
    feedback: [],
  },
];

/* ------------------------------------------------------------------ */
/*  Readiness scoring                                                 */
/* ------------------------------------------------------------------ */
function readiness(d) {
  const items = [
    { label: "Key contacts", done: d.profile.contacts.length > 0 },
    { label: "Use case", done: !!d.profile.useCase },
    { label: "Pain points", done: !!d.profile.painPoints },
    { label: "Data sources", done: d.profile.tech.dataSources.length > 0 },
    { label: "Bandset", done: !!d.profile.tech.bandset },
    { label: "Cadence", done: !!d.profile.tech.cadence },
    { label: "AOI defined", done: !!(d.context.aoi && d.context.aoi.poly) },
    { label: "Problem statement", done: !!d.context.problem },
    { label: "Objectives", done: d.context.objectives.length > 0 },
    { label: "Success criteria", done: d.execution.successCriteria.length > 0 },
    { label: "Next steps", done: !!d.execution.nextSteps },
    { label: "All owners assigned", done: !!(d.owners.se && d.owners.cs && d.owners.analytics) },
  ];
  const score = Math.round((items.filter(i => i.done).length / items.length) * 100);
  return { score, items };
}

/* ------------------------------------------------------------------ */
/*  Small components                                                  */
/* ------------------------------------------------------------------ */
function Ring({ value, size = 56, stroke = 6, showVal = true }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - value / 100);
  const id = "rg" + Math.round(value) + size;
  return (
    <div className="ring-wrap" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <defs>
          <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#6D5DF6" />
            <stop offset="35%" stopColor="#0EA5B7" />
            <stop offset="70%" stopColor="#2FB67A" />
            <stop offset="100%" stopColor="#E0B02B" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#EEF1F6" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={`url(#${id})`}
          strokeWidth={stroke} strokeLinecap="round" strokeDasharray={c} strokeDashoffset={off}
          transform={`rotate(-90 ${size / 2} ${size / 2})`} style={{ transition: "stroke-dashoffset .5s ease" }} />
      </svg>
      {showVal && <span className="ring-val" style={{ fontSize: size * 0.26, color: "var(--ink)" }}>{value}</span>}
    </div>
  );
}

function OwnerAvatar({ name, role }) {
  if (!name) return <div className={`av empty`} title={`${role} — unassigned`}>+</div>;
  return <div className={`av ${role}`} title={`${role.toUpperCase()}: ${name}`}>{initials(name)}</div>;
}

function StageChip({ stage }) {
  if (stage === 5) return <span className="chip won"><CheckCircle2 size={12} />Closed Won</span>;
  if (stage <= 1) return <span className="chip early">{STAGES[stage]}</span>;
  return <span className="chip live">{STAGES[stage]}</span>;
}

function fmt(n) {
  if (!n) return "—";
  return "$" + (n / 1000).toFixed(0) + "k";
}

function AoiMap({ aoi }) {
  if (!aoi) {
    return (
      <div className="empty"><MapPin size={16} /> No area of interest mapped yet.</div>
    );
  }
  return (
    <div className="aoi" style={{ height: 280 }}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" width="100%" height="100%">
        <defs>
          <radialGradient id="terrain" cx="40%" cy="35%" r="80%">
            <stop offset="0%" stopColor="#13384a" />
            <stop offset="55%" stopColor="#0e2735" />
            <stop offset="100%" stopColor="#0a1822" />
          </radialGradient>
          <linearGradient id="aoifill" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#0EA5B7" stopOpacity="0.32" />
            <stop offset="100%" stopColor="#2FB67A" stopOpacity="0.18" />
          </linearGradient>
        </defs>
        <rect width="100" height="100" fill="url(#terrain)" />
        {/* faux satellite blocks */}
        {[...Array(7)].map((_, i) => [...Array(7)].map((_, j) => (
          <rect key={`${i}-${j}`} x={i * 14.3} y={j * 14.3} width="14.3" height="14.3"
            fill="#ffffff" opacity={((i * 3 + j * 7) % 11) / 220 + 0.005} />
        )))}
        {/* graticule */}
        {[...Array(9)].map((_, i) => (
          <line key={"v" + i} x1={i * 12.5} y1="0" x2={i * 12.5} y2="100" stroke="#5e8aa3" strokeWidth="0.2" opacity="0.25" />
        ))}
        {[...Array(9)].map((_, i) => (
          <line key={"h" + i} x1="0" y1={i * 12.5} x2="100" y2={i * 12.5} stroke="#5e8aa3" strokeWidth="0.2" opacity="0.25" />
        ))}
        {/* AOI polygon */}
        <polygon points={aoi.poly} fill="url(#aoifill)" stroke="#3fe0ee" strokeWidth="0.7"
          strokeLinejoin="round" />
        {aoi.poly.split(" ").map((p, i) => {
          const [x, y] = p.split(",");
          return <circle key={i} cx={x} cy={y} r="0.9" fill="#7ff0fb" />;
        })}
      </svg>
      <div className="badge"><Layers size={11} /> AOI · GeoJSON</div>
      <div className="cap">
        {aoi.name}<br />
        ◎ {aoi.center}<br />
        ▦ {aoi.area}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Deal list                                                         */
/* ------------------------------------------------------------------ */
function DealList({ deals, onOpen }) {
  const [q, setQ] = useState("");
  const [stage, setStage] = useState("all");
  const [person, setPerson] = useState("all");

  const filtered = deals.filter(d => {
    const matchQ = (d.company + d.sector + d.id).toLowerCase().includes(q.toLowerCase());
    const matchS = stage === "all" || String(d.stage) === stage;
    const matchP = person === "all" ||
      [d.owners.director, d.owners.se, d.owners.cs, d.owners.analytics].includes(person);
    return matchQ && matchS && matchP;
  });

  return (
    <>
      <h2 className="section-title">Deals</h2>
      <p className="section-sub">Customer passports across the Pixxel sales pipeline · {deals.length} active</p>
      <div className="cp-filters">
        <div className="cp-search">
          <Search size={17} color="var(--muted2)" />
          <input placeholder="Search company, sector or deal ID…" value={q} onChange={e => setQ(e.target.value)} />
        </div>
        <div className="cp-select">
          <select value={stage} onChange={e => setStage(e.target.value)}>
            <option value="all">All stages</option>
            {STAGES.map((s, i) => <option key={i} value={i}>{s}</option>)}
          </select>
          <ChevronDown size={15} className="chev" />
        </div>
        <div className="cp-select">
          <select value={person} onChange={e => setPerson(e.target.value)}>
            <option value="all">All team members</option>
            {ORDER.map(role => (
              <optgroup key={role} label={ROLE_LABEL[role] + (role === "owner" ? "s" : role === "analytics" ? " team" : "s")}>
                {(TEAM[role] || []).map(p => <option key={role + p} value={p}>{p}</option>)}
              </optgroup>
            ))}
          </select>
          <ChevronDown size={15} className="chev" />
        </div>
      </div>

      <div className="cp-grid">
        {filtered.map(d => {
          const { score } = readiness(d);
          return (
            <div key={d.id} className="cp-card" onClick={() => onOpen(d.id)}>
              <div className="row">
                <div>
                  <h3>{d.company}</h3>
                  <div className="cp-sector"><Satellite size={13} /> {d.sector}</div>
                </div>
                <Ring value={score} size={46} stroke={5} />
              </div>
              <div style={{ marginTop: 14, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <StageChip stage={d.stage} />
                <span className="cp-amount">{fmt(d.amount)}</span>
              </div>
              <div className="owners">
                <OwnerAvatar name={d.owners.director} role="dir" />
                <OwnerAvatar name={d.owners.se} role="se" />
                <OwnerAvatar name={d.owners.cs} role="cs" />
                <OwnerAvatar name={d.owners.analytics} role="an" />
                <div style={{ flex: 1 }} />
                <span className="cp-amount" style={{ color: "var(--muted2)", fontSize: 11 }}>{d.id}</span>
              </div>
              <div className="meta"><Clock size={12} /> Updated {d.lastActivity} · synced from HubSpot</div>
            </div>
          );
        })}
      </div>
      {filtered.length === 0 && <div className="empty" style={{ marginTop: 8 }}>No deals match these filters. Try clearing the search.</div>}
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  Passport detail                                                   */
/* ------------------------------------------------------------------ */
function Passport({ deal, onBack, canEdit, onUpdate, onAssign, onNotifyAll, onPostToSlack, slackChannel, slackSending, slackStatus, toast }) {
  const [tab, setTab] = useState("profile");
  const [showChecklist, setShowChecklist] = useState(false);
  const [assignOpen, setAssignOpen] = useState(null);
  const { score, items } = readiness(deal);
  const missing = items.filter(i => !i.done);

  const assign = (role, name) => {
    onAssign(role, name);
    setAssignOpen(null);
  };

  return (
    <>
      <button className="cp-back" onClick={onBack}><ChevronLeft size={16} /> All deals</button>

      {/* header */}
      <div className="cp-head">
        <div className="spectral" />
        <div className="grat" />
        <div className="htop">
          <div>
            <h1>{deal.company}</h1>
            <div className="hsub">
              <span>{deal.sector}</span><span className="dot" />
              <span className="mono">{deal.id}</span><span className="dot" />
              <span className="mono">HubSpot {deal.hubspotId}</span><span className="dot" />
              <span>{fmt(deal.amount)} ACV</span>
            </div>
          </div>
          <div className="h-actions">
            <button className="btn ghost" onClick={() => toast("PDF export — would generate a shareable passport PDF")}>
              <Download size={14} /> Export PDF
            </button>
            <button className="btn ghost" disabled title="Needs PlanHat token + tenant ID (with CS team)">
              <ExternalLink size={14} /> Push to PlanHat
            </button>
            <button className={`btn slack${slackSending ? " sending" : ""}`} onClick={onPostToSlack}>
              <MessageSquare size={14} /> {slackSending ? "Posting…" : `Post to ${slackChannel ? slackChannel.name : "Slack"}`}
            </button>
            <button className="btn solid" onClick={onNotifyAll}>
              <Bell size={14} /> Notify owners
            </button>
          </div>
        </div>

        {slackStatus && (
          <div className={`slack-status${slackStatus.ok ? "" : " err"}`}>
            {slackStatus.ok ? <CheckCheck size={14} /> : <AlertTriangle size={14} />}
            {slackStatus.msg}
          </div>
        )}

        {/* stage bar */}
        <div className="stage-bar">
          {STAGES.map((s, i) => (
            <div key={i} className={"stage-seg " + (i < deal.stage ? "done" : i === deal.stage ? "cur" : "")}>
              <div className="bar" />
              <div className="lbl">{s}</div>
            </div>
          ))}
        </div>
        <div className="hs-writeback">
          <span className="hs-dot" /> Stage, amount &amp; deal owner sync live with HubSpot · {deal.hubspotId}
        </div>
        {deal.lastContact && (() => {
          const lc = deal.lastContact;
          const warmthLabel = lc.daysAgo <= 3 ? "Warm" : lc.daysAgo <= 14 ? "Cooling" : "Cold";
          const dotCls = lc.daysAgo <= 3 ? "warm" : lc.daysAgo <= 14 ? "cool" : "cold";
          return (
            <div className="last-contact">
              <div className="lc-item"><span className="lc-label">Last HubSpot contact</span> {lc.date}</div>
              <div className="lc-item"><span className="lc-label">Owner</span> {lc.owner}</div>
              <div className="lc-item"><span className={`lc-dot ${dotCls}`} /> {warmthLabel} — {lc.daysAgo}d ago</div>
            </div>
          );
        })()}
      </div>

      {/* ownership + readiness */}
      <div className="cp-railrow">
        <div className="owners-panel">
          {ORDER.map(role => {
            const short = ROLE_SHORT[role];
            const name = deal.owners[role];
            const label = ROLE_LABEL[role];
            return (
              <div className="owner-slot" key={role}>
                <OwnerAvatar name={name} role={short} />
                <div className="meta">
                  <div className="role-tag">{label}</div>
                  {name
                    ? <div className="nm">{name}</div>
                    : (canEdit
                      ? <button className="assign" onClick={() => setAssignOpen(assignOpen === role ? null : role)}>+ Assign owner</button>
                      : <div className="nm" style={{ color: "var(--muted2)" }}>Unassigned</div>)}
                </div>
                {assignOpen === role && (
                  <div className="assign-menu">
                    {TEAM[role].map(p => (
                      <button key={p} onClick={() => assign(role, p)}>{p}</button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="readiness-panel" onClick={() => setShowChecklist(s => !s)}>
          <Ring value={score} size={58} stroke={6} />
          <div className="txt">
            <div className="k">Handover readiness</div>
            <div className="v">{score === 100 ? "Ready" : missing.length + " items left"}</div>
            <small>{showChecklist ? "Hide checklist" : "View checklist"}</small>
          </div>
        </div>
      </div>

      {showChecklist && (
        <div className="checklist">
          <h4>What's needed for a clean SE → CS handover</h4>
          <div className="items">
            {items.map((it, i) => (
              <div key={i} className={"cl-item " + (it.done ? "" : "miss")}>
                {it.done ? <CheckCircle2 size={16} color="var(--ok)" /> : <Circle size={16} color="var(--muted2)" />}
                {it.label}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* tabs */}
      <div className="cp-tabs">
        {[["profile", Building2, "Profile"], ["context", Target, "Context"], ["execution", Activity, "Execution"], ["notes", FileText, "Notes"], ["feedback", MessageSquare, "Customer Feedback"]].map(([k, Ic, lbl]) => (
          <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k)}><Ic size={15} />{lbl}</button>
        ))}
      </div>

      {tab === "profile" && <ProfileTab d={deal} />}
      {tab === "context" && <ContextTab d={deal} />}
      {tab === "execution" && <ExecutionTab d={deal} canEdit={canEdit} onUpdate={onUpdate} />}
      {tab === "notes" && <NotesTab d={deal} canEdit={canEdit} onUpdate={onUpdate} toast={toast} />}
      {tab === "feedback" && <FeedbackTab d={deal} canEdit={canEdit} onUpdate={onUpdate} toast={toast} />}
    </>
  );
}

/* ---- tab blocks ---- */
function SecStamp({ stamp }) {
  if (!stamp || !stamp.by) return null;
  return <span className="sec-stamp"><Clock size={10} /> {stamp.by} · {stamp.at}</span>;
}

function Block({ icon: Ic, title, children, action, stamp }) {
  return (
    <div className="block">
      <div className="bhead">
        <div className="lhs"><div className="ic"><Ic size={15} /></div><h3>{title}</h3></div>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          {stamp && <SecStamp stamp={stamp} />}
          {action}
        </div>
      </div>
      {children}
    </div>
  );
}
function Field({ k, children }) {
  return <div><div className="k">{k}</div><div className="v">{children || <span style={{ color: "var(--muted2)" }}>Not captured yet</span>}</div></div>;
}

function ProfileTab({ d }) {
  const t = d.profile.tech;
  const st = d.sectionStamps || {};
  return (
    <>
      <div className="cols">
        <Block icon={Building2} title="Company & contacts" stamp={st.profile}>
          <div className="kv">
            {d.profile.contacts.length ? d.profile.contacts.map((c, i) => (
              <div key={i}>
                <div style={{ fontSize: 13.5, fontWeight: 600 }}>{c.name}</div>
                <div style={{ fontSize: 12, color: "var(--muted)" }}>{c.role}</div>
                <div className="link" style={{ marginTop: 3 }}><Mail size={12} /> {c.email}</div>
              </div>
            )) : <div className="empty"><Users size={15} /> No contacts captured.</div>}
          </div>
        </Block>
        <Block icon={Users} title="Team & expertise">
          <div className="kv"><Field k="Customer team">{d.profile.team}</Field></div>
        </Block>
      </div>

      <Block icon={Target} title="Use case · pain points · support needs">
        <div className="kv">
          <Field k="Use case">{d.profile.useCase}</Field>
          <Field k="Pain points">{d.profile.painPoints}</Field>
          <Field k="Support needs">{d.profile.supportNeeds}</Field>
        </div>
      </Block>

      <Block icon={Radar} title="Technical requirements">
        <div className="kv">
          <div>
            <div className="k">Data sources</div>
            <div className="tags" style={{ marginTop: 4 }}>
              {t.dataSources.length ? t.dataSources.map((s, i) => <span key={i} className="tag spec">{s}</span>)
                : <span style={{ color: "var(--muted2)", fontSize: 13 }}>Not captured yet</span>}
            </div>
          </div>
          <Field k="Bandset">{t.bandset}</Field>
          <Field k="Cadence / revisit">{t.cadence}</Field>
          <div style={{ display: "flex", gap: 18, marginTop: 2 }}>
            {t.aoiLink
              ? <span className="link"><MapPin size={13} /> AOI definition <ExternalLink size={12} /></span>
              : <span className="empty" style={{ flex: "none", padding: "7px 11px" }}><MapPin size={13} /> No AOI link</span>}
            {t.feasibilityLink
              ? <span className="link"><Gauge size={13} /> Feasibility study <ExternalLink size={12} /></span>
              : <span className="empty" style={{ flex: "none", padding: "7px 11px" }}><Gauge size={13} /> No feasibility link</span>}
          </div>
        </div>
      </Block>
    </>
  );
}

function ContextTab({ d }) {
  return (
    <>
      <Block icon={Target} title="Problem statement">
        <div className="kv"><Field k="What the customer is trying to solve">{d.context.problem}</Field></div>
      </Block>
      <div className="cols">
        <Block icon={CheckCircle2} title="Objectives">
          {d.context.objectives.length ? d.context.objectives.map((o, i) => (
            <div className="li" key={i}><span className="b" />{o}</div>
          )) : <div className="empty"><Target size={15} /> No objectives defined.</div>}
        </Block>
        <Block icon={MapPin} title="Area of interest">
          <AoiMap aoi={d.context.aoi} />
        </Block>
      </div>
    </>
  );
}

const CAPTURE_STATUSES = ["Tasked","Captured","QC In Progress","QC Passed","QC Failed","Shared"];
const QC_FAIL_REASONS = ["BBR","Cloud cover","Geometric","Bounding-box","Striping","Geolocation","Other"];
const STATUS_CLS = { "Tasked":"cs-tasked","Captured":"cs-captured","QC In Progress":"cs-qcprog","QC Passed":"cs-qcpass","QC Failed":"cs-qcfail","Shared":"cs-shared" };
const STATUS_DOT = { "Tasked":"var(--se)","Captured":"var(--accent)","QC In Progress":"var(--warn)","QC Passed":"var(--ok)","QC Failed":"var(--bad)","Shared":"var(--an)" };

function CaptureLog({ entries, canEdit, onAdd }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ date: new Date().toISOString().slice(0,10), status:"Tasked", failReason:"", note:"" });
  const submit = () => {
    if (!form.note.trim()) return;
    onAdd({ ...form, id:"cl"+Date.now(), author:"You", ts:"Just now" });
    setOpen(false);
    setForm({ date: new Date().toISOString().slice(0,10), status:"Tasked", failReason:"", note:"" });
  };
  return (
    <div className="clog-wrap">
      {entries.map((e, i) => (
        <div className="clog-entry" key={e.id}>
          <div className="clog-timeline">
            <span className="clog-dot" style={{ background: STATUS_DOT[e.status] || "var(--muted2)" }} />
            {i < entries.length - 1 && <span className="clog-line" />}
          </div>
          <div style={{ flex:1 }}>
            <div style={{ display:"flex", alignItems:"center", gap:9, flexWrap:"wrap" }}>
              <span className={`clog-status ${STATUS_CLS[e.status]||""}`}>{e.status}</span>
              <span style={{ fontSize:11.5, fontFamily:"var(--font-mono)", color:"var(--muted2)" }}>{e.date}</span>
              {e.failReason && <span className="clog-reason"><AlertTriangle size={11} /> {e.failReason}</span>}
            </div>
            <div className="clog-note">{e.note}</div>
            <div className="clog-meta">{e.author} · {e.ts}</div>
          </div>
        </div>
      ))}
      {entries.length === 0 && <div className="empty"><Camera size={15} /> No capture events logged yet.</div>}
      {canEdit && !open && (
        <div className="clog-add" onClick={() => setOpen(true)}><Plus size={15} /> Log capture event</div>
      )}
      {open && (
        <div className="clog-form">
          <div className="clog-form-row">
            <div>
              <div className="k" style={{ fontFamily:"var(--font-mono)", fontSize:"9.5px", letterSpacing:".1em", textTransform:"uppercase", color:"var(--muted2)", marginBottom:4 }}>Date</div>
              <input type="date" style={{ width:"100%", border:"1px solid var(--line)", borderRadius:8, padding:"7px 10px", fontFamily:"inherit", fontSize:13, outline:"none" }}
                value={form.date} onChange={e => setForm(f => ({ ...f, date:e.target.value }))} />
            </div>
            <div>
              <div className="k" style={{ fontFamily:"var(--font-mono)", fontSize:"9.5px", letterSpacing:".1em", textTransform:"uppercase", color:"var(--muted2)", marginBottom:4 }}>Status</div>
              <div className="cp-select">
                <select value={form.status} onChange={e => setForm(f => ({ ...f, status:e.target.value, failReason:"" }))}>
                  {CAPTURE_STATUSES.map(s => <option key={s}>{s}</option>)}
                </select>
                <ChevronDown size={13} className="chev" />
              </div>
            </div>
          </div>
          {form.status === "QC Failed" && (
            <div style={{ marginBottom:10 }}>
              <div className="k" style={{ fontFamily:"var(--font-mono)", fontSize:"9.5px", letterSpacing:".1em", textTransform:"uppercase", color:"var(--muted2)", marginBottom:4 }}>Failure reason</div>
              <div className="cp-select">
                <select value={form.failReason} onChange={e => setForm(f => ({ ...f, failReason:e.target.value }))}>
                  <option value="">— select —</option>
                  {QC_FAIL_REASONS.map(r => <option key={r}>{r}</option>)}
                </select>
                <ChevronDown size={13} className="chev" />
              </div>
            </div>
          )}
          <div>
            <div className="k" style={{ fontFamily:"var(--font-mono)", fontSize:"9.5px", letterSpacing:".1em", textTransform:"uppercase", color:"var(--muted2)", marginBottom:4 }}>Note</div>
            <textarea style={{ width:"100%", border:"1px solid var(--line)", borderRadius:9, padding:"9px 12px", fontFamily:"inherit", fontSize:13, resize:"vertical", minHeight:72, outline:"none" }}
              placeholder="What happened? Any details about the capture, QC result, or delivery…"
              value={form.note} onChange={e => setForm(f => ({ ...f, note:e.target.value }))} />
          </div>
          <div style={{ display:"flex", gap:8, justifyContent:"flex-end", marginTop:10 }}>
            <button className="btn ghost" style={{ color:"var(--muted)", border:"1px solid var(--line)", background:"#fff" }} onClick={() => setOpen(false)}>Cancel</button>
            <button className="btn solid" onClick={submit}><Camera size={13} /> Save event</button>
          </div>
        </div>
      )}
    </div>
  );
}

function ActionPlan({ items, canEdit, onToggle, onAdd }) {
  const [apView, setApView] = useState("open");   // open | thisweek | done
  const [newTask, setNewTask] = useState("");
  const [newOwner, setNewOwner] = useState("");
  const [newDue, setNewDue] = useState("");
  const today = new Date();
  const weekEnd = new Date(today); weekEnd.setDate(today.getDate() + 7);
  const parseDate = s => s ? new Date(s) : null;
  const isOverdue = d => { const pd = parseDate(d); return pd && pd < today; };
  const isThisWeek = d => { const pd = parseDate(d); return pd && pd >= today && pd <= weekEnd; };
  const dueCls = d => isOverdue(d) ? "overdue" : isThisWeek(d) ? "thisweek" : "";

  const filtered = items.filter(a =>
    apView === "open" ? !a.done :
    apView === "thisweek" ? (!a.done && isThisWeek(a.due)) :
    a.done
  );

  const add = () => {
    if (!newTask.trim()) return;
    onAdd({ id:"a"+Date.now(), task:newTask.trim(), owner:newOwner, due:newDue, done:false });
    setNewTask(""); setNewOwner(""); setNewDue("");
  };

  return (
    <>
      <div className="ap-tabs">
        {[["open","Open"],["thisweek","This week"],["done","Done"]].map(([k,l]) => (
          <button key={k} className={`ap-tab${apView===k?" on":""}`} onClick={() => setApView(k)}>{l}
            <span style={{ marginLeft:5, fontSize:10.5, opacity:.65 }}>
              {k==="open" ? items.filter(a=>!a.done).length : k==="thisweek" ? items.filter(a=>!a.done&&isThisWeek(a.due)).length : items.filter(a=>a.done).length}
            </span>
          </button>
        ))}
      </div>
      {filtered.map(a => (
        <div className={`ap-item${a.done?" done-item":""}`} key={a.id}>
          <div className={`ap-check${a.done?" checked":""}`} onClick={() => onToggle(a.id)}>
            {a.done && <CheckCircle2 size={13} color="#fff" />}
          </div>
          <div style={{ flex:1 }}>
            <div className={`ap-task${a.done?" done-text":""}`}>{a.task}</div>
            <div className="ap-meta">
              {a.owner && <span>👤 {a.owner}</span>}
              {a.due && <span className={`ap-due ${dueCls(a.due)}`}><CalendarClock size={10} /> {a.due}{isOverdue(a.due) && !a.done ? " · Overdue" : isThisWeek(a.due) && !a.done ? " · This week" : ""}</span>}
            </div>
          </div>
        </div>
      ))}
      {filtered.length === 0 && <div className="empty" style={{ marginBottom:10 }}><ListChecks size={15} /> No {apView === "thisweek" ? "items due this week" : apView + " items"}.</div>}
      {canEdit && (
        <div className="ap-add-row">
          <input placeholder="Add action item…" value={newTask} onChange={e => setNewTask(e.target.value)}
            onKeyDown={e => e.key==="Enter" && add()} />
          <select value={newOwner} onChange={e => setNewOwner(e.target.value)}>
            <option value="">Owner…</option>
            {[...TEAM.se,...TEAM.cs,...TEAM.analytics].map(p => <option key={p}>{p}</option>)}
          </select>
          <input type="date" value={newDue} onChange={e => setNewDue(e.target.value)} />
          <button className="btn solid" onClick={add} style={{ whiteSpace:"nowrap" }}><Plus size={13} /> Add</button>
        </div>
      )}
    </>
  );
}

function ExecutionTab({ d, canEdit, onUpdate }) {
  const e = d.execution;
  const st = d.sectionStamps || {};

  const addCaptureEvent = (entry) => {
    onUpdate({ ...d, execution: { ...e, captureLog: [...(e.captureLog||[]), entry] } });
  };
  const toggleAction = (id) => {
    onUpdate({ ...d, execution: { ...e, actionItems: (e.actionItems||[]).map(a => a.id===id ? {...a, done:!a.done} : a) } });
  };
  const addAction = (item) => {
    onUpdate({ ...d, execution: { ...e, actionItems: [...(e.actionItems||[]), item] } });
  };

  return (
    <>
      <div className="cols">
        <Block icon={CheckCircle2} title="Success criteria" stamp={st.execution}>
          {e.successCriteria.length ? e.successCriteria.map((s, i) => (
            <div className="li" key={i}><CheckCircle2 size={15} color="var(--ok)" style={{ flex: "none", marginTop: 1 }} />{s}</div>
          )) : <div className="empty"><CheckCircle2 size={15} /> No success criteria yet — needed before handover.</div>}
        </Block>
        <Block icon={Activity} title="Proofs of concept">
          {e.pocs.length ? e.pocs.map((p, i) => (
            <div key={i} style={{ marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <span style={{ fontSize: 13.5, fontWeight: 600 }}>{p.name}</span>
                <span className="tag" style={{ background: p.status === "Complete" ? "#E3F7EC" : "var(--accent-soft)", color: p.status === "Complete" ? "#1f8a57" : "var(--accent-deep)" }}>{p.status}</span>
              </div>
              <div style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 3 }}>{p.note}</div>
            </div>
          )) : <div className="empty"><Activity size={15} /> No POCs logged.</div>}
        </Block>
      </div>

      {/* Capture / image progress log */}
      <Block icon={Camera} title="Capture & image progress log">
        <CaptureLog entries={e.captureLog||[]} canEdit={canEdit} onAdd={addCaptureEvent} />
      </Block>

      <div className="cols">
        <Block icon={Layers} title="Sample data delivered">
          {e.sampleData.length ? e.sampleData.map((s, i) => (
            <div className="li" key={i}><span className="b" />{s}</div>
          )) : <div className="empty"><Layers size={15} /> Nothing delivered yet.</div>}
        </Block>
        <Block icon={MapPin} title="Sample delivery AOI">
          <AoiMap aoi={e.sampleAoi} />
        </Block>
      </div>

      <div className="cols">
        <Block icon={AlertTriangle} title="Risks">
          {e.risks.length ? e.risks.map((r, i) => (
            <div className="risk" key={i}>
              <span className={"sev " + r.sev}>{r.sev}</span>
              <span style={{ fontSize: 13, color: "var(--ink2)", lineHeight: 1.5 }}>{r.text}</span>
            </div>
          )) : <div className="empty"><AlertTriangle size={15} /> No risks flagged.</div>}
        </Block>
        <Block icon={TrendingUp} title="Next steps & commercial pathway">
          <div className="kv">
            <Field k="Next steps">{e.nextSteps}</Field>
            <Field k="Commercial model">{e.commercial}</Field>
          </div>
        </Block>
      </div>

      {/* Structured action plan */}
      <Block icon={ListChecks} title="Action plan">
        <ActionPlan items={e.actionItems||[]} canEdit={canEdit} onToggle={toggleAction} onAdd={addAction} />
      </Block>
    </>
  );
}

function NotesTab({ d, canEdit, onUpdate, toast }) {
  const [draft, setDraft] = useState("");
  const post = () => {
    if (!draft.trim()) return;
    const now = "Just now";
    const mentions = (draft.match(/@([\w ]+?)(?=[,.!?]|$)/g) || []).map(m => m.slice(1).trim());
    const entry = { date: now, author: "You", text: draft.trim(), mentions };
    onUpdate({ ...d, notes: { ...d.notes, activity: [entry, ...d.notes.activity] } });
    setDraft("");
    toast(mentions.length ? `Update posted · notified ${mentions.join(", ")}` : "Update posted to the activity feed");
  };
  const renderText = (t, mentions) => {
    if (!mentions || !mentions.length) return t;
    let parts = [t];
    mentions.forEach(m => {
      parts = parts.flatMap(p => typeof p === "string"
        ? p.split("@" + m).flatMap((seg, i) => i === 0 ? [seg] : [<span key={m + i} className="mention">@{m}</span>, seg])
        : [p]);
    });
    return parts;
  };

  return (
    <>
      {canEdit && (
        <div className="composer">
          <textarea placeholder="Post an update… use @ to mention a teammate (e.g. @Priya Shah)"
            value={draft} onChange={e => setDraft(e.target.value)} />
          <div className="crow">
            <span className="hint"><AtSign size={13} /> Mentions notify that person by email</span>
            <button className="btn solid" onClick={post}><Send size={13} /> Post update</button>
          </div>
        </div>
      )}

      <div className="cols">
        <div>
          <Block icon={FileText} title="Meeting notes">
            {d.notes.meetings.map((m, i) => (
              <div key={i} style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--muted2)" }}>{m.date} · {m.author}</div>
                <div style={{ fontSize: 13.5, color: "var(--ink2)", lineHeight: 1.55, marginTop: 4 }}>{m.text}</div>
              </div>
            ))}
          </Block>
          <Block icon={Paperclip} title="Attachments">
            {d.notes.attachments.length ? d.notes.attachments.map((a, i) => (
              <div className="attach" key={i}>
                <div className="ai"><FileText size={16} /></div>
                <div><div className="an2">{a.name}</div><div className="as">{a.type.toUpperCase()} · {a.size}</div></div>
                <Download size={15} color="var(--muted2)" style={{ marginLeft: "auto" }} />
              </div>
            )) : <div className="empty"><Paperclip size={15} /> No attachments.</div>}
          </Block>
        </div>

        <Block icon={Activity} title="Activity & change history">
          {d.notes.activity.map((a, i) => (
            <div className="feed-item" key={i}>
              <div className="av" style={{ background: a.author === "You" ? "var(--accent)" : "var(--ink2)", width: 30, height: 30 }}>
                {a.author === "You" ? "★" : initials(a.author)}
              </div>
              <div>
                <div className="ft"><strong>{a.author}</strong> {renderText(a.text, a.mentions)}</div>
                <div className="fm">{a.date}</div>
              </div>
            </div>
          ))}
        </Block>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  Leadership dashboard                                              */
/* ------------------------------------------------------------------ */
function Dashboard({ deals, onOpen }) {
  const scores = deals.map(d => readiness(d).score);
  const avg = Math.round(scores.reduce((a, b) => a + b, 0) / deals.length);
  const pipeline = deals.reduce((a, d) => a + d.amount, 0);
  const ready = deals.filter(d => readiness(d).score >= 90).length;
  const atRisk = deals.filter(d => readiness(d).score < 60).map(d => ({ ...d, s: readiness(d).score }));

  const byStage = STAGES.map((s, i) => ({ name: s, count: deals.filter(d => d.stage === i).length }));
  const maxStage = Math.max(...byStage.map(b => b.count), 1);

  return (
    <>
      <h2 className="section-title">Leadership view</h2>
      <p className="section-sub">Portfolio handover health across all active passports</p>

      <div className="dash-grid">
        <div className="stat"><div className="k">Avg readiness</div><div className="v">{avg}%</div>
          <div className="d"><Gauge size={13} /> across {deals.length} deals</div></div>
        <div className="stat"><div className="k">Handover-ready</div><div className="v">{ready}</div>
          <div className="d"><CheckCircle2 size={13} color="var(--ok)" /> ≥ 90% complete</div></div>
        <div className="stat"><div className="k">Pipeline ACV</div><div className="v">${(pipeline / 1000000).toFixed(2)}M</div>
          <div className="d"><TrendingUp size={13} /> synced from HubSpot</div></div>
        <div className="stat"><div className="k">Need attention</div><div className="v">{atRisk.length}</div>
          <div className="d"><AlertTriangle size={13} color="var(--warn)" /> below 60%</div></div>
      </div>

      <div className="cols">
        <Block icon={BarChart3} title="Deals by stage">
          <div className="barlist">
            {byStage.map((b, i) => (
              <div className="br" key={i}>
                <span style={{ color: "var(--muted)" }}>{b.name}</span>
                <div className="track"><div className="fill" style={{ width: `${(b.count / maxStage) * 100}%` }} /></div>
                <span className="mono" style={{ textAlign: "right" }}>{b.count}</span>
              </div>
            ))}
          </div>
        </Block>

        <Block icon={AlertTriangle} title="Low readiness — needs SE input">
          {atRisk.length ? atRisk.map(d => (
            <div className="alert-row" key={d.id} onClick={() => onOpen(d.id)}>
              <Ring value={d.s} size={38} stroke={4} />
              <div>
                <div className="anm">{d.company}</div>
                <div className="as2">{STAGES[d.stage]} · {readiness(d).items.filter(i => !i.done).length} items missing</div>
              </div>
              <ChevronLeft size={16} color="var(--muted2)" style={{ marginLeft: "auto", transform: "rotate(180deg)" }} />
            </div>
          )) : <div className="empty"><CheckCircle2 size={15} /> Every passport is in good shape.</div>}
        </Block>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  Customer Feedback tab                                             */
/* ------------------------------------------------------------------ */
const SAT_META = {
  "Very Satisfied":   { cls: "vsat", dot: "var(--accent)",  label: "Very Satisfied" },
  "Satisfied":        { cls: "sat",  dot: "var(--ok)",      label: "Satisfied" },
  "Neutral":          { cls: "neu",  dot: "var(--muted2)",  label: "Neutral" },
  "Unsatisfied":      { cls: "s",    dot: "var(--warn)",    label: "Unsatisfied" },
  "Very Unsatisfied": { cls: "vs",   dot: "var(--bad)",     label: "Very Unsatisfied" },
};

function SatBadge({ sat, size = "md" }) {
  const m = SAT_META[sat] || SAT_META["Neutral"];
  return (
    <span className={`sat-chip ${m.cls}`} style={{ fontSize: size === "sm" ? 10.5 : 11.5 }}>
      <span className="sat-dot" style={{ background: m.dot }} />
      {m.label}
    </span>
  );
}

function FeedbackTab({ d, canEdit, onUpdate, toast }) {
  const [filter, setFilter] = useState("all");
  const [expanded, setExpanded] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    satisfaction: "Satisfied", keyInsights: "", imageBandsets: "",
    imageIds: "", customerExpertise: "Intermediate", softwareUsed: "",
    followUpDate: "", followUpAssignedTo: "", type: "Client",
  });

  const items = (d.feedback || []).filter(f => filter === "all" || f.satisfaction === filter);
  const counts = Object.fromEntries(Object.keys(SAT_META).map(k => [k, (d.feedback || []).filter(f => f.satisfaction === k).length]));

  const submitFeedback = () => {
    if (!form.keyInsights.trim()) { toast("Key insights are required"); return; }
    const entry = {
      id: "fb-" + Date.now(), date: new Date().toISOString().slice(0, 10), type: form.type,
      satisfaction: form.satisfaction, keyInsights: form.keyInsights,
      imageBandsets: form.imageBandsets.split(",").map(s => s.trim()).filter(Boolean),
      imageIds: form.imageIds.split(",").map(s => s.trim()).filter(Boolean),
      customerExpertise: form.customerExpertise, softwareUsed: form.softwareUsed,
      followUpDate: form.followUpDate, followUpAssignedTo: form.followUpAssignedTo,
      supportingFiles: [], notionPageId: "",
    };
    onUpdate({ ...d, feedback: [entry, ...(d.feedback || [])] });
    setShowForm(false);
    setForm({ satisfaction: "Satisfied", keyInsights: "", imageBandsets: "", imageIds: "", customerExpertise: "Intermediate", softwareUsed: "", followUpDate: "", followUpAssignedTo: "", type: "Client" });
    toast("Feedback entry added — ready to sync to Notion");
  };

  return (
    <>
      {/* Notion connection banner */}
      <div className="fb-notion-banner">
        <div style={{ fontSize: 22 }}>𝗡</div>
        <div>
          <div className="nb-title">Notion · Satellite Imagery Customer Feedback</div>
          <div className="nb-status">
            <span className="notion-dot" />
            <span>Not connected — entries entered here won't sync until Notion is linked</span>
          </div>
        </div>
        <button className="connect-btn" onClick={() => toast("Connect Notion in Claude.ai Settings → Connectors, then entries will sync automatically")}>
          Connect Notion →
        </button>
      </div>

      {/* Header + filters */}
      <div className="fb-header">
        <div className="fb-sat-bar">
          <button className={`sat-chip all${filter === "all" ? " on" : ""}`} onClick={() => setFilter("all")}>
            All · {(d.feedback || []).length}
          </button>
          {Object.entries(SAT_META).map(([k, m]) => counts[k] > 0 && (
            <button key={k} className={`sat-chip ${m.cls}${filter === k ? " on" : ""}`} onClick={() => setFilter(f => f === k ? "all" : k)}>
              <span className="sat-dot" style={{ background: m.dot }} />{m.label} · {counts[k]}
            </button>
          ))}
        </div>
        {canEdit && (
          <button className="fb-notion-btn" onClick={() => setShowForm(s => !s)}>
            <Plus size={14} /> {showForm ? "Cancel" : "Add feedback"}
          </button>
        )}
      </div>

      {/* Add form */}
      {showForm && (
        <div className="block" style={{ marginBottom: 16 }}>
          <div className="bhead"><div className="lhs"><div className="ic"><MessageSquare size={15} /></div><h3>New feedback entry</h3></div></div>
          <div className="fb-grid">
            <div>
              <div className="k">Satisfaction</div>
              <div className="cp-select" style={{ marginTop: 4 }}>
                <select value={form.satisfaction} onChange={e => setForm(f => ({ ...f, satisfaction: e.target.value }))}>
                  {Object.keys(SAT_META).map(k => <option key={k} value={k}>{k}</option>)}
                </select>
                <ChevronDown size={13} className="chev" />
              </div>
            </div>
            <div>
              <div className="k">Type</div>
              <div className="cp-select" style={{ marginTop: 4 }}>
                <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
                  {["Client", "Internal", "POC review", "Renewal"].map(t => <option key={t}>{t}</option>)}
                </select>
                <ChevronDown size={13} className="chev" />
              </div>
            </div>
            <div>
              <div className="k">Customer expertise</div>
              <div className="cp-select" style={{ marginTop: 4 }}>
                <select value={form.customerExpertise} onChange={e => setForm(f => ({ ...f, customerExpertise: e.target.value }))}>
                  {["Beginner", "Intermediate", "Advanced", "Expert"].map(l => <option key={l}>{l}</option>)}
                </select>
                <ChevronDown size={13} className="chev" />
              </div>
            </div>
            <div>
              <div className="k">Software used</div>
              <input style={{ width:"100%",border:"1px solid var(--line)",borderRadius:8,padding:"8px 11px",fontSize:13,fontFamily:"inherit",marginTop:4,outline:"none" }}
                placeholder="e.g. Python, ENVI, ArcGIS" value={form.softwareUsed}
                onChange={e => setForm(f => ({ ...f, softwareUsed: e.target.value }))} />
            </div>
            <div>
              <div className="k">Image bandsets (comma-separated)</div>
              <input style={{ width:"100%",border:"1px solid var(--line)",borderRadius:8,padding:"8px 11px",fontSize:13,fontFamily:"inherit",marginTop:4,outline:"none" }}
                placeholder="e.g. VNIR 400–1000nm, SWIR" value={form.imageBandsets}
                onChange={e => setForm(f => ({ ...f, imageBandsets: e.target.value }))} />
            </div>
            <div>
              <div className="k">Image IDs (comma-separated)</div>
              <input style={{ width:"100%",border:"1px solid var(--line)",borderRadius:8,padding:"8px 11px",fontSize:13,fontFamily:"inherit",marginTop:4,outline:"none",fontFamily:"var(--font-mono)" }}
                placeholder="FF03_20260421_..." value={form.imageIds}
                onChange={e => setForm(f => ({ ...f, imageIds: e.target.value }))} />
            </div>
            <div>
              <div className="k">Follow-up date</div>
              <input type="date" style={{ width:"100%",border:"1px solid var(--line)",borderRadius:8,padding:"8px 11px",fontSize:13,fontFamily:"inherit",marginTop:4,outline:"none" }}
                value={form.followUpDate} onChange={e => setForm(f => ({ ...f, followUpDate: e.target.value }))} />
            </div>
            <div>
              <div className="k">Follow-up assigned to</div>
              <div className="cp-select" style={{ marginTop: 4 }}>
                <select value={form.followUpAssignedTo} onChange={e => setForm(f => ({ ...f, followUpAssignedTo: e.target.value }))}>
                  <option value="">— select —</option>
                  {[...TEAM.se, ...TEAM.cs, ...TEAM.analytics].map(p => <option key={p} value={p}>{p}</option>)}
                </select>
                <ChevronDown size={13} className="chev" />
              </div>
            </div>
          </div>
          <div style={{ marginTop: 14 }}>
            <div className="k">Key insights *</div>
            <textarea style={{ width:"100%",border:"1px solid var(--line)",borderRadius:10,padding:"11px 13px",fontSize:13.5,fontFamily:"inherit",marginTop:4,resize:"vertical",minHeight:90,outline:"none" }}
              placeholder="What did the customer say? What worked, what didn't? Any commitments or action points?"
              value={form.keyInsights} onChange={e => setForm(f => ({ ...f, keyInsights: e.target.value }))} />
          </div>
          <div style={{ marginTop: 12, display:"flex", justifyContent:"flex-end", gap:8 }}>
            <button className="btn ghost" style={{ color:"var(--muted)", border:"1px solid var(--line)", background:"#fff" }} onClick={() => setShowForm(false)}>Cancel</button>
            <button className="btn solid" onClick={submitFeedback}><Send size={13} /> Save entry</button>
          </div>
        </div>
      )}

      {/* Feedback entries */}
      {items.length === 0 ? (
        <div className="fb-empty">
          <MessageSquare size={32} color="var(--line)" />
          <h4>{filter === "all" ? "No feedback yet" : `No ${filter} feedback`}</h4>
          <p style={{ fontSize:13, maxWidth:320, margin:"0 auto" }}>
            {filter === "all"
              ? "Add the first feedback entry above, or connect Notion to pull entries from the Satellite Imagery Customer Feedback database."
              : "Try clearing the satisfaction filter."}
          </p>
        </div>
      ) : (
        items.map(fb => (
          <div className="fb-card" key={fb.id}>
            <div className="fb-card-head" onClick={() => setExpanded(expanded === fb.id ? null : fb.id)}>
              <SatBadge sat={fb.satisfaction} />
              <div className="co">
                <div className="title">{fb.keyInsights.slice(0, 72)}{fb.keyInsights.length > 72 ? "…" : ""}</div>
                <div className="meta">
                  <span>{fb.date}</span>
                  <span>·</span>
                  <span>{fb.type}</span>
                  <span>·</span>
                  <span>{fb.customerExpertise}</span>
                  {fb.followUpDate && <><span>·</span><span>Follow-up {fb.followUpDate}</span></>}
                </div>
              </div>
              <ChevronDown size={16} color="var(--muted2)" style={{ transform: expanded === fb.id ? "rotate(180deg)" : "none", transition:".15s" }} />
            </div>
            {expanded === fb.id && (
              <div className="fb-card-body">
                <div className="fb-insights">{fb.keyInsights}</div>
                <div className="fb-grid" style={{ marginTop: 16 }}>
                  <div>
                    <div className="k">Image bandsets</div>
                    <div className="v">{fb.imageBandsets.length ? fb.imageBandsets.join(", ") : "—"}</div>
                  </div>
                  <div>
                    <div className="k">Image IDs</div>
                    <div className="fb-ids">{fb.imageIds.length ? fb.imageIds.map((id, i) => <span className="fb-id" key={i}>{id}</span>) : <span className="v">—</span>}</div>
                  </div>
                  <div>
                    <div className="k">Customer expertise</div>
                    <div className="v">{fb.customerExpertise || "—"}</div>
                  </div>
                  <div>
                    <div className="k">Software used</div>
                    <div className="v">{fb.softwareUsed || "—"}</div>
                  </div>
                  <div>
                    <div className="k">Follow-up date</div>
                    <div className="v">{fb.followUpDate || "—"}</div>
                  </div>
                  <div>
                    <div className="k">Follow-up assigned to</div>
                    <div className="v">{fb.followUpAssignedTo || "—"}</div>
                  </div>
                  {fb.supportingFiles && fb.supportingFiles.length > 0 && (
                    <div style={{ gridColumn: "span 2" }}>
                      <div className="k">Supporting files</div>
                      <div className="tags" style={{ marginTop: 4 }}>{fb.supportingFiles.map((f, i) => <span className="tag" key={i}>{f}</span>)}</div>
                    </div>
                  )}
                </div>
                {fb.notionPageId ? (
                  <div style={{ marginTop: 14 }}>
                    <span className="link"><ExternalLink size={12} /> View in Notion</span>
                  </div>
                ) : (
                  <div style={{ marginTop: 14, fontSize: 11.5, color: "var(--muted2)", fontFamily: "var(--font-mono)", display:"flex", alignItems:"center", gap:6 }}>
                    <span className="notion-dot" /> Not yet synced to Notion
                  </div>
                )}
              </div>
            )}
          </div>
        ))
      )}
    </>
  );
}

/* ------------------------------------------------------------------ */
/*  App shell                                                         */
/* ------------------------------------------------------------------ */
/* ================================================================
   SUPABASE DATA LAYER
   ================================================================ */

const SUPABASE_URL = (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_SUPABASE_URL)
  || "https://plspunlkmkvplgcsncpa.supabase.co";
const SUPABASE_ANON_KEY = (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_SUPABASE_ANON_KEY)
  || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBsc3B1bmxrbWt2cGxnY3NuY3BhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE3NzA3NTMsImV4cCI6MjA5NzM0Njc1M30.SMybWhOWztQFzXSlosW1c_MVdndXsVOLcyfGJUd63eE";

const SB_HEADERS = {
  "apikey": SUPABASE_ANON_KEY,
  "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
  "Content-Type": "application/json",
  "Prefer": "return=representation",
};

async function sbGet(table, params = "") {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}${params}`, { headers: SB_HEADERS });
  if (!r.ok) throw new Error(`${r.status}: ${await r.text()}`);
  return r.json();
}

async function sbPost(table, body) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
    method: "POST", headers: SB_HEADERS, body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`${r.status}: ${await r.text()}`);
  const text = await r.text();
  return text ? JSON.parse(text) : {};
}

async function sbPatch(table, id, body) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${table}?id=eq.${id}`, {
    method: "PATCH",
    headers: { ...SB_HEADERS, "Prefer": "return=minimal" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`${r.status}: ${await r.text()}`);
}

const CORE_PIPELINES_LIST = [
  "Global Commercial Pipeline",
];

async function fetchPassports({ pipeline, stage, ownerFilter, search } = {}) {
  const pipes = (pipeline && pipeline !== "all") ? [pipeline] : CORE_PIPELINES_LIST;
  const pipeQ = pipes.map(p => `pipeline.eq.${encodeURIComponent(p)}`).join(",");
  let params = `?select=id,hubspot_deal_id,company,deal_id_display,hubspot_stage,hubspot_stage_idx,hubspot_amount,hubspot_last_contacted,hubspot_last_contact_owner,hubspot_synced_at,owner_director,owner_se,owner_cs,owner_analytics,pipeline,last_activity_label,updated_at&or=(${pipeQ})&order=updated_at.desc&limit=300`;
  if (stage !== undefined && stage !== "all") params += `&hubspot_stage_idx=eq.${stage}`;
  let data = await sbGet("handover_passports", params);
  if (ownerFilter) {
    data = data.filter(d => [d.owner_se, d.owner_cs, d.owner_analytics, d.owner_director].includes(ownerFilter));
  }
  if (search) {
    const s = search.toLowerCase();
    data = data.filter(d => (d.company||"").toLowerCase().includes(s) || (d.deal_id_display||"").toLowerCase().includes(s));
  }
  return data;
}

async function fetchPassportDetail(id) {
  const [passport, contacts, pocs, risks, sampleData, captureLog, actionItems, meetingNotes, activityFeed, attachments, feedback] = await Promise.all([
    sbGet("handover_passports", `?id=eq.${id}`).then(r => r[0]),
    sbGet("deal_contacts", `?passport_id=eq.${id}`),
    sbGet("deal_pocs", `?passport_id=eq.${id}`),
    sbGet("deal_risks", `?passport_id=eq.${id}`),
    sbGet("deal_sample_data", `?passport_id=eq.${id}`),
    sbGet("capture_log", `?passport_id=eq.${id}&order=entry_date.desc`),
    sbGet("action_items", `?passport_id=eq.${id}&order=due_date.asc`),
    sbGet("meeting_notes", `?passport_id=eq.${id}&order=created_at.desc`),
    sbGet("activity_feed", `?passport_id=eq.${id}&order=created_at.desc`),
    sbGet("attachments", `?passport_id=eq.${id}`),
    sbGet("customer_feedback", `?passport_id=eq.${id}&order=feedback_date.desc`),
  ]);
  return { passport, contacts: contacts||[], pocs: pocs||[], risks: risks||[], sampleData: sampleData||[], captureLog: captureLog||[], actionItems: actionItems||[], meetingNotes: meetingNotes||[], activityFeed: activityFeed||[], attachments: attachments||[], feedback: feedback||[] };
}

function calcReadiness(passport, contacts) {
  const p = passport || {};
  const items = [
    { label: "Key contacts",      done: contacts && contacts.length > 0 },
    { label: "Use case",          done: !!p.use_case },
    { label: "Pain points",       done: !!p.pain_points },
    { label: "Data sources",      done: p.data_sources && p.data_sources.length > 0 },
    { label: "Bandset",           done: !!p.bandset },
    { label: "Cadence",           done: !!p.cadence },
    { label: "AOI defined",       done: !!p.aoi_geojson },
    { label: "Problem statement", done: !!p.problem_statement },
    { label: "Objectives",        done: p.objectives && p.objectives.length > 0 },
    { label: "Success criteria",  done: p.success_criteria && p.success_criteria.length > 0 },
    { label: "Next steps",        done: !!p.next_steps },
    { label: "All owners",        done: !!(p.owner_se && p.owner_cs && p.owner_analytics) },
  ];
  return { score: Math.round(items.filter(i => i.done).length / items.length * 100), items };
}

async function assignOwner(passportId, role, name) {
  await sbPatch("handover_passports", passportId, { [`owner_${role}`]: name });
}

async function addActivityEntry(passportId, author, body, mentions = []) {
  await sbPost("activity_feed", { passport_id: passportId, author, body, mentions, entry_type: "note" });
}

async function addCaptureLogEntry(passportId, entry) {
  await sbPost("capture_log", { passport_id: passportId, ...entry });
}

async function toggleActionItem(itemId, done) {
  await sbPatch("action_items", itemId, { done, done_at: done ? new Date().toISOString() : null });
}

async function addActionItem(passportId, item) {
  await sbPost("action_items", { passport_id: passportId, ...item });
}

async function addFeedbackEntry(passportId, entry) {
  await sbPost("customer_feedback", { passport_id: passportId, ...entry });
}

async function triggerHubspotSync() {
  const r = await fetch(`${SUPABASE_URL}/functions/v1/hubspot-sync`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${SUPABASE_ANON_KEY}` },
    body: JSON.stringify({}),
  });
  return r.json();
}

async function sendSlackNotification(event, payload, passportId, channelId) {
  const r = await fetch(`${SUPABASE_URL}/functions/v1/slack-notify`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${SUPABASE_ANON_KEY}` },
    body: JSON.stringify({ event, ...payload, passport_id: passportId, channel_id: channelId }),
  });
  return r.json();
}

/* ================================================================
   LIVE DEAL LIST  (replaces mock DealList)
   ================================================================ */

// Pipeline colour dots
const PIPE_COLORS = {
  "EAP Private Sector": "#2D7FF9",
  "EAP (ROW)": "#0EA5B7",
  "Bespoke Analytics (EMEA & APAC)": "#7A5AF5",
  "Public Sector (USA)": "#E07A2B",
  "Public Sector (India)": "#2FB67A",
  "Global Commercial Pipeline": "#E5564B",
  "Other": "#929BAB",
};

function DealListLive({ deals, loading, onOpen, pipelineFilter, setPipelineFilter, stageFilter, setStageFilter, ownerFilter, setOwnerFilter, searchQ, setSearchQ }) {
  return (
    <>
      <h2 className="section-title">Deals</h2>
      <p className="section-sub">
        Core pipeline passports · {deals.length} loaded
        {loading && <span style={{ color: "var(--accent)", marginLeft: 8 }}>Refreshing…</span>}
      </p>

      <div className="cp-filters">
        <div className="cp-search">
          <Search size={17} color="var(--muted2)" />
          <input
            placeholder="Search company or deal ID…"
            value={searchQ}
            onChange={e => setSearchQ(e.target.value)}
          />
          {searchQ && <button onClick={() => setSearchQ("")} style={{ color:"var(--muted2)", padding:2 }}><X size={14}/></button>}
        </div>

        {/* Pipeline filter */}
        <div className="cp-select">
          <select value={pipelineFilter} onChange={e => setPipelineFilter(e.target.value)}>
            <option value="all">All core pipelines</option>
            {CORE_PIPELINES_LIST.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
          <ChevronDown size={15} className="chev" />
        </div>

        {/* Stage filter */}
        <div className="cp-select">
          <select value={stageFilter} onChange={e => setStageFilter(e.target.value === "all" ? "all" : parseInt(e.target.value))}>
            <option value="all">All stages</option>
            {["Discovery","Technical Validation","Quote / Solution Scoping","Proposal","Contracting & Negotiation","Closed Won","Closed Lost"].map((s,i) =>
              <option key={i} value={i}>{s}</option>
            )}
          </select>
          <ChevronDown size={15} className="chev" />
        </div>

        {/* Owner filter — grouped by team */}
        <div className="cp-select">
          <select value={ownerFilter} onChange={e => setOwnerFilter(e.target.value)}>
            <option value="">All team members</option>
            <optgroup label="Sales Owners">
              {TEAM.owner.map(p => <option key={"o-"+p} value={p}>{p}</option>)}
            </optgroup>
            <optgroup label="Sales Engineers">
              {TEAM.se.map(p => <option key={"s-"+p} value={p}>{p}</option>)}
            </optgroup>
            <optgroup label="Customer Success">
              {TEAM.cs.map(p => <option key={"c-"+p} value={p}>{p}</option>)}
            </optgroup>
            <optgroup label="Analytics">
              {TEAM.analytics.map(p => <option key={"a-"+p} value={p}>{p}</option>)}
            </optgroup>
          </select>
          <ChevronDown size={15} className="chev" />
        </div>
      </div>

      {loading && deals.length === 0 ? (
        <div style={{ textAlign:"center", padding:"60px 0", color:"var(--muted)" }}>
          <Satellite size={32} color="var(--accent)" style={{ display:"block", margin:"0 auto 12px", opacity:.5 }} />
          Loading deals from HubSpot…
        </div>
      ) : deals.length === 0 ? (
        <div className="empty">No deals match these filters.</div>
      ) : (
        <div className="cp-grid">
          {deals.map(d => {
            const { score } = calcReadiness(d, []);
            const pipeColor = PIPE_COLORS[d.pipeline] || "#929BAB";
            const warmth = d.hubspot_last_contacted
              ? Math.floor((Date.now() - new Date(d.hubspot_last_contacted).getTime()) / 86400000)
              : null;
            return (
              <div key={d.id} className="cp-card" onClick={() => onOpen(d.id)}>
                <div className="row">
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:7, marginBottom:4 }}>
                      <span style={{ width:8, height:8, borderRadius:"50%", background:pipeColor, flex:"none" }} />
                      <span style={{ fontSize:10.5, color:"var(--muted2)", fontFamily:"var(--font-mono)", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{d.pipeline}</span>
                    </div>
                    <h3 style={{ margin:0, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{d.company}</h3>
                  </div>
                  <Ring value={score} size={46} stroke={5} />
                </div>
                <div style={{ marginTop:14, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <StageChip stage={d.hubspot_stage_idx} />
                  <span className="cp-amount">{d.hubspot_amount ? "$" + (d.hubspot_amount/1000).toFixed(0) + "k" : "—"}</span>
                </div>
                <div className="owners" style={{ marginTop:14 }}>
                  <OwnerAvatar name={d.owner_director} role="dir" />
                  <OwnerAvatar name={d.owner_se} role="se" />
                  <OwnerAvatar name={d.owner_cs} role="cs" />
                  <OwnerAvatar name={d.owner_analytics} role="an" />
                  <div style={{ flex:1 }} />
                  <span className="cp-amount" style={{ color:"var(--muted2)", fontSize:11 }}>{d.deal_id_display}</span>
                </div>
                <div className="meta" style={{ marginTop:10 }}>
                  <Clock size={12} />
                  {d.last_activity_label || "Unknown"}
                  {warmth !== null && (
                    <span style={{ marginLeft:6, color: warmth <= 3 ? "var(--ok)" : warmth <= 14 ? "var(--warn)" : "var(--bad)", fontSize:11 }}>
                      · contacted {warmth}d ago
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}

/* ================================================================
   PASSPORT DETAIL ADAPTER
   Maps Supabase shape → existing Passport component props
   ================================================================ */

function PassportDetail({ data, onBack, canEdit, onRefresh, onAssign, onNotifyAll, onPostToSlack, slackChannel, slackSending, slackStatus, toast }) {
  const { passport: p, contacts, pocs, risks, sampleData, captureLog, actionItems, meetingNotes, activityFeed, attachments, feedback } = data;
  const { score, items: readinessItems } = calcReadiness(p, contacts);

  // Map Supabase passport → the shape Passport component expects
  const deal = {
    id: p.id,
    company: p.company,
    sector: p.sector || p.pipeline || "",
    hubspotId: p.hubspot_deal_id,
    lastActivity: p.last_activity_label || "Unknown",
    lastContact: p.hubspot_last_contacted ? {
      date: new Date(p.hubspot_last_contacted).toLocaleDateString("en-GB", { day:"2-digit", month:"short", year:"numeric" }),
      owner: p.hubspot_last_contact_owner || p.owner_se || "—",
      warmth: (() => { const d = Math.floor((Date.now() - new Date(p.hubspot_last_contacted).getTime()) / 86400000); return d <= 3 ? "warm" : d <= 14 ? "cool" : "cold"; })(),
      daysAgo: Math.floor((Date.now() - new Date(p.hubspot_last_contacted).getTime()) / 86400000),
    } : null,
    stage: p.hubspot_stage_idx || 0,
    amount: p.hubspot_amount,
    owners: { owner: p.owner_director, se: p.owner_se, cs: p.owner_cs, analytics: p.owner_analytics },
    sectionStamps: { profile: p.stamp_profile, context: p.stamp_context, execution: p.stamp_execution },
    profile: {
      contacts: contacts.map(c => ({ name: c.name, role: c.role, email: c.email })),
      team: p.customer_team || "",
      useCase: p.use_case || "",
      painPoints: p.pain_points || "",
      supportNeeds: p.support_needs || "",
      tech: {
        dataSources: p.data_sources || [],
        bandset: p.bandset || "",
        cadence: p.cadence || "",
        aoiLink: !!p.aoi_link,
        feasibilityLink: !!p.feasibility_link,
      },
    },
    context: {
      problem: p.problem_statement || "",
      objectives: p.objectives || [],
      aoi: p.aoi_geojson || null,
    },
    execution: {
      successCriteria: p.success_criteria || [],
      pocs: pocs.map(poc => ({ name: poc.name, status: poc.status, note: poc.note })),
      sampleData: sampleData.map(s => s.description),
      risks: risks.map(r => ({ sev: r.severity, text: r.description })),
      nextSteps: p.next_steps || "",
      commercial: p.commercial_model || "",
      captureLog: captureLog.map(e => ({
        id: e.id, date: e.entry_date, status: e.status, failReason: e.fail_reason || "",
        note: e.note, author: e.author, ts: new Date(e.created_at).toLocaleString("en-GB", { month:"short", day:"2-digit", hour:"2-digit", minute:"2-digit" }),
      })),
      sampleAoi: p.sample_aoi_geojson || null,
      actionItems: actionItems.map(a => ({
        id: a.id, task: a.task, owner: a.owner, due: a.due_date, done: a.done,
      })),
    },
    notes: {
      meetings: meetingNotes.map(n => ({ date: n.note_date || "", author: n.author, text: n.body })),
      activity: activityFeed.map(a => ({
        date: new Date(a.created_at).toLocaleString("en-GB", { month:"short", day:"2-digit", hour:"2-digit", minute:"2-digit" }),
        author: a.author, text: a.body, mentions: a.mentions || [],
      })),
      attachments: attachments.map(a => ({ name: a.file_name, type: a.file_type, size: a.file_size })),
    },
    feedback: feedback.map(f => ({
      id: f.id, date: f.feedback_date, type: f.feedback_type,
      satisfaction: f.satisfaction, keyInsights: f.key_insights || "",
      imageBandsets: f.image_bandsets || [], imageIds: f.image_ids || [],
      customerExpertise: f.customer_expertise, softwareUsed: f.software_used,
      followUpDate: f.follow_up_date, followUpAssignedTo: f.follow_up_assigned_to,
      supportingFiles: f.supporting_files || [], notionPageId: f.notion_page_id || "",
    })),
  };

  // Intercept onUpdate to persist changes
  const handleUpdate = async (updated) => {
    // Activity feed post
    if (updated._activityPost) {
      const { author, body, mentions } = updated._activityPost;
      await addActivityEntry(p.id, author, body, mentions);
      await onRefresh();
      return;
    }
    // Capture log entry
    if (updated._captureEntry) {
      await addCaptureLogEntry(p.id, updated._captureEntry);
      await onRefresh();
      return;
    }
    // Action item toggle
    if (updated._toggleAction) {
      await toggleActionItem(updated._toggleAction.id, updated._toggleAction.done);
      await onRefresh();
      return;
    }
    // Action item add
    if (updated._addAction) {
      await addActionItem(p.id, updated._addAction);
      await onRefresh();
      return;
    }
    // Feedback entry
    if (updated._feedbackEntry) {
      await addFeedbackEntry(p.id, updated._feedbackEntry);
      await onRefresh();
      return;
    }
    // General passport field update — build Supabase fields from changed deal
    const fields = {};
    if (updated.owners) {
      if (updated.owners.owner !== deal.owners.owner) fields.owner_director = updated.owners.owner;
      if (updated.owners.se !== deal.owners.se) fields.owner_se = updated.owners.se;
      if (updated.owners.cs !== deal.owners.cs) fields.owner_cs = updated.owners.cs;
      if (updated.owners.analytics !== deal.owners.analytics) fields.owner_analytics = updated.owners.analytics;
    }
    if (Object.keys(fields).length) {
      await sbPatch("handover_passports", p.id, fields);
      await onRefresh();
    }
  };

  return (
    <Passport
      deal={deal}
      onBack={onBack}
      canEdit={canEdit}
      onUpdate={handleUpdate}
      onAssign={(r, name) => onAssign(r, name)}
      onNotifyAll={onNotifyAll}
      onPostToSlack={onPostToSlack}
      slackChannel={slackChannel}
      slackSending={slackSending}
      slackStatus={slackStatus}
      toast={toast}
    />
  );
}

/* ================================================================
   LIVE DASHBOARD  (replaces mock Dashboard)
   ================================================================ */

function DashboardLive({ deals, onOpen }) {
  const active = deals.filter(d => d.hubspot_stage_idx < 6);
  const pipeline = active.reduce((a, d) => a + (d.hubspot_amount || 0), 0);
  const closedWon = deals.filter(d => d.hubspot_stage_idx === 5).length;
  const noOwner = deals.filter(d => !d.owner_cs || !d.owner_se).length;

  const byStage = ["Discovery","Technical Validation","Quote / Solution Scoping","Proposal","Contracting & Negotiation","Closed Won"]
    .map((s, i) => ({ name: s, count: deals.filter(d => d.hubspot_stage_idx === i).length }));
  const maxStage = Math.max(...byStage.map(b => b.count), 1);

  const byPipeline = CORE_PIPELINES_LIST.map(name => ({
    name, count: deals.filter(d => d.pipeline === name).length, color: PIPE_COLORS[name],
  }));
  const maxPipe = Math.max(...byPipeline.map(b => b.count), 1);

  const needsAttention = deals.filter(d => {
    const { score } = calcReadiness(d, []);
    return score < 50 && d.hubspot_stage_idx >= 1 && d.hubspot_stage_idx < 5;
  }).slice(0, 8);

  return (
    <>
      <h2 className="section-title">Leadership view</h2>
      <p className="section-sub">Live pipeline health across core Pixxel deals</p>

      <div className="dash-grid">
        <div className="stat">
          <div className="k">Active deals</div>
          <div className="v">{active.length}</div>
          <div className="d"><Activity size={13} /> across core pipelines</div>
        </div>
        <div className="stat">
          <div className="k">Pipeline ACV</div>
          <div className="v">${(pipeline/1000000).toFixed(1)}M</div>
          <div className="d"><TrendingUp size={13} /> live from HubSpot</div>
        </div>
        <div className="stat">
          <div className="k">Closed Won</div>
          <div className="v">{closedWon}</div>
          <div className="d"><CheckCircle2 size={13} color="var(--ok)" /> active customers</div>
        </div>
        <div className="stat">
          <div className="k">Needs SE/CS</div>
          <div className="v">{noOwner}</div>
          <div className="d"><AlertTriangle size={13} color="var(--warn)" /> unassigned owners</div>
        </div>
      </div>

      <div className="cols">
        <Block icon={BarChart3} title="Deals by stage">
          <div className="barlist">
            {byStage.map((b, i) => (
              <div className="br" key={i}>
                <span style={{ color:"var(--muted)", fontSize:12.5 }}>{b.name}</span>
                <div className="track"><div className="fill" style={{ width:`${(b.count/maxStage)*100}%` }} /></div>
                <span className="mono" style={{ textAlign:"right", fontSize:12 }}>{b.count}</span>
              </div>
            ))}
          </div>
        </Block>

        <Block icon={Satellite} title="Deals by pipeline">
          <div className="barlist">
            {byPipeline.map((b, i) => (
              <div className="br" key={i}>
                <span style={{ color:"var(--muted)", fontSize:12.5 }}>{b.name.replace(" (EMEA & APAC)","").replace("Public Sector ","PS ")}</span>
                <div className="track"><div className="fill" style={{ width:`${(b.count/maxPipe)*100}%`, background:`linear-gradient(90deg, ${b.color}, ${b.color}88)` }} /></div>
                <span className="mono" style={{ textAlign:"right", fontSize:12 }}>{b.count}</span>
              </div>
            ))}
          </div>
        </Block>
      </div>

      <Block icon={AlertTriangle} title="Active deals missing SE or CS owner">
        {needsAttention.length ? needsAttention.map(d => {
          const { score } = calcReadiness(d, []);
          return (
            <div className="alert-row" key={d.id} onClick={() => onOpen(d.id)}>
              <Ring value={score} size={38} stroke={4} />
              <div>
                <div className="anm">{d.company}</div>
                <div className="as2">
                  {d.hubspot_stage} · {!d.owner_se ? "No SE" : !d.owner_cs ? "No CS" : "Incomplete"}
                </div>
              </div>
              <ChevronLeft size={16} color="var(--muted2)" style={{ marginLeft:"auto", transform:"rotate(180deg)" }} />
            </div>
          );
        }) : <div className="empty"><CheckCircle2 size={15} /> All active deals have SE and CS assigned.</div>}
      </Block>
    </>
  );
}

/* ================================================================
   APP SHELL (Supabase-wired)
   ================================================================ */
export default function App() {
  const [deals, setDeals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [lastSynced, setLastSynced] = useState(null);
  const [pipelineFilter, setPipelineFilter] = useState("all");
  const [stageFilter, setStageFilter] = useState("all");
  const [ownerFilter, setOwnerFilter] = useState("");
  const [searchQ, setSearchQ] = useState("");

  // ── Passport detail state ───────────────────────────────────
  const [openId, setOpenId] = useState(null);           // supabase uuid
  const [passportData, setPassportData] = useState(null); // full detail
  const [detailLoading, setDetailLoading] = useState(false);

  // ── UI state ────────────────────────────────────────────────
  const [view, setView] = useState("deals");
  const [role, setRole] = useState("se");
  const [toastMsg, setToastMsg] = useState(null);
  const [notifs, setNotifs] = useState([]);
  const [bellOpen, setBellOpen] = useState(false);
  const [slackChannel, setSlackChannel] = useState(DEFAULT_CHANNEL);
  const [slackStatus, setSlackStatus] = useState(null);
  const [slackSending, setSlackSending] = useState(false);

  const toast = (m) => {
    setToastMsg(m);
    window.clearTimeout(window.__t);
    window.__t = window.setTimeout(() => setToastMsg(null), 3000);
  };
  const canEdit = role === "se";
  const unread = notifs.filter(n => !n.read).length;

  // ── Load deal list ──────────────────────────────────────────
  const loadDeals = async () => {
    setLoading(true);
    try {
      const data = await fetchPassports({
        pipeline: pipelineFilter,
        stage: stageFilter,
        ownerFilter: ownerFilter || null,
        search: searchQ || null,
      });
      setDeals(data);
    } catch (e) {
      toast("Failed to load deals: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  // Reload when filters change
  useEffect(() => { loadDeals(); }, [pipelineFilter, stageFilter, ownerFilter]);

  // Debounced search
  useEffect(() => {
    const t = setTimeout(loadDeals, 300);
    return () => clearTimeout(t);
  }, [searchQ]);

  // ── Open passport detail ────────────────────────────────────
  const openPassport = async (id) => {
    setOpenId(id);
    setView("deals");
    setSlackStatus(null);
    setDetailLoading(true);
    window.scrollTo(0, 0);
    try {
      const data = await fetchPassportDetail(id);
      setPassportData(data);
    } catch (e) {
      toast("Failed to load passport: " + e.message);
    } finally {
      setDetailLoading(false);
    }
  };

  const closePassport = () => {
    setOpenId(null);
    setPassportData(null);
    loadDeals(); // refresh list in case something changed
  };

  // Refresh passport detail after mutations
  const refreshDetail = async () => {
    if (!openId) return;
    const data = await fetchPassportDetail(openId);
    setPassportData(data);
    // Also refresh the deal in the list
    loadDeals();
  };

  // ── HubSpot sync ────────────────────────────────────────────
  const syncHubspot = async () => {
    setSyncing(true);
    toast("Syncing with HubSpot…");
    try {
      const result = await triggerHubspotSync();
      if (result.ok) {
        setLastSynced(new Date());
        toast(`✓ HubSpot sync complete — ${result.synced} deals updated`);
        loadDeals();
      } else {
        toast("HubSpot sync failed: " + result.error);
      }
    } catch (e) {
      toast("Sync error: " + e.message);
    } finally {
      setSyncing(false);
    }
  };

  // ── Assignment ──────────────────────────────────────────────
  const handleAssign = async (passportId, r, name) => {
    const deal = deals.find(d => d.id === passportId) || passportData?.passport;
    try {
      await assignOwner(passportId, r, name);
      // Push in-app notification
      setNotifs(ns => [{
        id: Math.random(), person: name, email: emailFor(name),
        role: r, company: deal?.company || "Deal",
        dealId: deal?.deal_id_display || "", time: "Just now", read: false
      }, ...ns]);
      toast(`${name} assigned as ${ROLE_LABEL[r]} — notifying via Slack…`);
      // Send Slack immediately
      const { score } = calcReadinessFromData(passportData);
      const result = await sendSlackNotification("assignment", {
        person: name, role: ROLE_LABEL[r],
        person_slack: slackFor(name), person_email: emailFor(name),
        company: deal?.company, dealId: deal?.deal_id_display,
        stage: deal?.hubspot_stage, amount: deal?.hubspot_amount,
        readiness: score, assignedBy: "Team",
      }, passportId, slackChannel.id);
      toast(result.ok
        ? `✓ ${name} notified in ${slackChannel.name}`
        : `Assignment saved · Slack: ${result.error}`);
      refreshDetail();
    } catch (e) {
      toast("Assignment failed: " + e.message);
    }
  };

  // ── Notify all owners ───────────────────────────────────────
  const handleNotifyAll = async () => {
    if (!passportData) return;
    const p = passportData.passport;
    const owners = [p.owner_director, p.owner_se, p.owner_cs, p.owner_analytics].filter(Boolean);
    owners.forEach(name => {
      setNotifs(ns => [{
        id: Math.random(), person: name, email: emailFor(name),
        role: "se", company: p.company, dealId: p.deal_id_display, time: "Just now", read: false
      }, ...ns]);
    });
    toast(`Notifying ${owners.length} owners in ${slackChannel.name}…`);
    const { score } = calcReadinessFromData(passportData);
    const result = await sendSlackNotification("notify_all", {
      company: p.company, dealId: p.deal_id_display,
      stage: p.hubspot_stage, amount: p.hubspot_amount,
      readiness: score, postedBy: "Team",
      owners: { owner: p.owner_director, se: p.owner_se, cs: p.owner_cs, analytics: p.owner_analytics },
    }, p.id, slackChannel.id);
    toast(result.ok
      ? `✓ ${owners.length} owners notified in ${slackChannel.name}`
      : `Sent in-app · Slack: ${result.error}`);
  };

  // ── Post to Slack ───────────────────────────────────────────
  const handlePostToSlack = async () => {
    if (!passportData) return;
    setSlackSending(true);
    setSlackStatus(null);
    const p = passportData.passport;
    const { score } = calcReadinessFromData(passportData);
    const result = await sendSlackNotification("deal_summary", {
      company: p.company, dealId: p.deal_id_display,
      stage: p.hubspot_stage, amount: p.hubspot_amount,
      readiness: score, postedBy: "Team",
      owners: { owner: p.owner_director, se: p.owner_se, cs: p.owner_cs, analytics: p.owner_analytics },
    }, p.id, slackChannel.id);
    setSlackSending(false);
    setSlackStatus(result.ok
      ? { ok: true, msg: `Posted to ${slackChannel.name}` }
      : { ok: false, msg: result.error });
  };

  // Helper: calc readiness from passportData object
  const calcReadinessFromData = (pd) => {
    if (!pd) return { score: 0, items: [] };
    return calcReadiness(pd.passport, pd.contacts);
  };

  // Format last synced time
  const syncLabel = lastSynced
    ? lastSynced.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" })
    : (deals[0]?.hubspot_synced_at
      ? "synced " + new Date(deals[0].hubspot_synced_at).toLocaleTimeString("en-GB", { hour:"2-digit", minute:"2-digit" })
      : "not yet synced");

  return (
    <div className="cp-root">
      <style>{CSS}</style>

      <div className="cp-top">
        <div className="cp-brand">
          {PIXXEL_LOGO_URL
            ? <img className="cp-logo-img" src={PIXXEL_LOGO_URL} alt="Pixxel" onError={e => { e.currentTarget.style.display = "none"; }} />
            : <span className="cp-wordmark">pi<span className="x">xx</span>el</span>}
          <span className="cp-brand-div" />
          <span>Customer Passport<small>SE → CS → Analytics</small></span>
        </div>
        <div className="cp-nav">
          <button className={view === "deals" && !openId ? "on" : ""} onClick={() => { setView("deals"); closePassport(); }}>
            <LayoutGrid size={15} /> Deals
          </button>
          <button className={view === "dashboard" ? "on" : ""} onClick={() => { setView("dashboard"); closePassport(); }}>
            <BarChart3 size={15} /> Leadership
          </button>
        </div>
        <div className="cp-spacer" />

        {/* Slack channel picker */}
        <div className="slack-pill">
          <span className="slack-dot" /><b>Slack</b>
          <select style={{ border:"none", background:"transparent", fontSize:12, color:"var(--muted)", fontFamily:"inherit", cursor:"pointer", outline:"none" }}
            value={slackChannel.id}
            onChange={e => setSlackChannel(SLACK_CHANNELS.find(c => c.id === e.target.value))}>
            {SLACK_CHANNELS.map(c => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
        </div>

        {/* HubSpot sync */}
        <div className="hs-pill">
          <span className="hs-dot" /> <b>HubSpot</b> · {syncLabel}
          <button className="syncnow" onClick={syncHubspot} disabled={syncing}>
            <Satellite size={12} /> {syncing ? "Syncing…" : "Sync now"}
          </button>
        </div>

        {/* Bell */}
        <div className="bell">
          <button className="btn-bell" onClick={() => { setBellOpen(o => !o); setNotifs(ns => ns.map(n => ({ ...n, read: true }))); }}>
            <Bell size={17} />
            {unread > 0 && <span className="badge">{unread}</span>}
          </button>
          {bellOpen && (
            <div className="notif-panel">
              <div className="notif-head">
                <h4>Notifications</h4>
                {notifs.length > 0 && <button onClick={() => setNotifs([])}>Clear all</button>}
              </div>
              <div className="notif-list">
                {notifs.length === 0
                  ? <div className="notif-empty">No notifications yet.<br />Assign someone to a deal to send one.</div>
                  : notifs.map(n => (
                    <div className={"notif-item" + (n.read ? "" : " unread")} key={n.id}>
                      <div className={"av " + (ROLE_SHORT[n.role] || "se")}>{initials(n.person)}</div>
                      <div>
                        <div className="nt"><b>{n.person}</b> was assigned as <b>{ROLE_LABEL[n.role] || n.role}</b> on {n.company}</div>
                        <div className="nch"><MessageSquare size={11} /> Slack · <Mail size={11} /> email · {n.time}</div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>

        <div className="cp-viewtoggle">
          <button className={role === "se" ? "on" : ""} onClick={() => setRole("se")}><Pencil size={13} /> SE (editing)</button>
          <button className={role === "cs" ? "on" : ""} onClick={() => setRole("cs")}><Eye size={13} /> CS (read-only)</button>
        </div>
      </div>

      <div className="cp-page">
        {role === "cs" && (
          <div className="cp-banner"><Lock size={15} /> Read-only briefing view — Customer Success can review everything captured, but editing is locked.</div>
        )}

        {openId
          ? detailLoading
            ? <div style={{ textAlign:"center", padding:"60px 0", color:"var(--muted)" }}>
                <Satellite size={28} color="var(--accent)" style={{ display:"block", margin:"0 auto 12px", opacity:.6 }} />
                Loading passport…
              </div>
            : passportData && (
                <PassportDetail
                  data={passportData}
                  onBack={closePassport}
                  canEdit={canEdit}
                  onRefresh={refreshDetail}
                  onAssign={(r, name) => handleAssign(openId, r, name)}
                  onNotifyAll={handleNotifyAll}
                  onPostToSlack={handlePostToSlack}
                  slackChannel={slackChannel}
                  slackSending={slackSending}
                  slackStatus={slackStatus}
                  toast={toast}
                />
              )
          : view === "dashboard"
            ? <DashboardLive deals={deals} onOpen={openPassport} />
            : <DealListLive
                deals={deals}
                loading={loading}
                onOpen={openPassport}
                pipelineFilter={pipelineFilter}
                setPipelineFilter={setPipelineFilter}
                stageFilter={stageFilter}
                setStageFilter={setStageFilter}
                ownerFilter={ownerFilter}
                setOwnerFilter={setOwnerFilter}
                searchQ={searchQ}
                setSearchQ={setSearchQ}
              />
        }
      </div>

      {toastMsg && <div className="toast"><span className="spectral-dot" />{toastMsg}</div>}
    </div>
  );
}
